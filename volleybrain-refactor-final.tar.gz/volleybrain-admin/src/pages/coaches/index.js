export { 
  CoachesPage, 
  ClickableCoachName, 
  ClickableTeamName,
  CoachDetailModal 
} from './CoachesPage'
