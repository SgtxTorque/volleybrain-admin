import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useSeason } from '../../contexts/SeasonContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { 
  Megaphone, DollarSign, Calendar, Clock, Users, Check, X
} from '../../constants/icons'

function BlastsPage({ showToast, activeView, roleContext }) {
  const { organization, profile, user } = useAuth()
  const { selectedSeason } = useSeason()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const [loading, setLoading] = useState(true)
  const [blasts, setBlasts] = useState([])
  const [teams, setTeams] = useState([])
  const [showComposeModal, setShowComposeModal] = useState(false)
  const [selectedBlast, setSelectedBlast] = useState(null)
  const [filterType, setFilterType] = useState('all')
  
  useEffect(() => {
    if (selectedSeason?.id) loadBlasts()
  }, [selectedSeason?.id])
  
  async function loadBlasts() {
    setLoading(true)
    try {
      // Load teams
      const { data: teamsData } = await supabase
        .from('teams')
        .select('*')
        .eq('season_id', selectedSeason.id)
      setTeams(teamsData || [])
      
      // Load blasts/announcements
      const { data: blastsData } = await supabase
        .from('messages')
        .select(`
          *,
          profiles:sender_id (full_name),
          teams:target_team_id (name, color),
          message_recipients (id, acknowledged, acknowledged_at, recipient_name)
        `)
        .eq('season_id', selectedSeason.id)
        .order('created_at', { ascending: false })
      
      // Calculate stats for each blast
      const blastsWithStats = (blastsData || []).map(blast => {
        const total = blast.message_recipients?.length || 0
        const acknowledged = blast.message_recipients?.filter(r => r.acknowledged).length || 0
        return {
          ...blast,
          total_recipients: total,
          acknowledged_count: acknowledged,
          read_percentage: total > 0 ? Math.round((acknowledged / total) * 100) : 0
        }
      })
      
      setBlasts(blastsWithStats)
    } catch (err) {
      console.error('Error loading blasts:', err)
      showToast?.('Error loading announcements', 'error')
    }
    setLoading(false)
  }
  
  const filteredBlasts = blasts.filter(b => {
    if (filterType === 'all') return true
    if (filterType === 'urgent') return b.priority === 'urgent'
    if (filterType === 'pending') return b.read_percentage < 100
    return b.message_type === filterType
  })
  
  const getTypeIcon = (type) => {
    switch(type) {
      case 'payment_reminder': return <DollarSign className="w-6 h-6" />
      case 'schedule_change': return <Calendar className="w-6 h-6" />
      case 'deadline': return <Clock className="w-6 h-6" />
      case 'announcement': return <Megaphone className="w-6 h-6" />
      default: return <Megaphone className="w-6 h-6" />
    }
  }
  
  const getTypeColor = (type) => {
    switch(type) {
      case 'payment_reminder': return 'bg-emerald-500/20 text-emerald-500'
      case 'schedule_change': return 'bg-blue-500/20 text-blue-500'
      case 'deadline': return 'bg-red-500/20 text-red-500'
      default: return 'bg-purple-500/20 text-purple-500'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${tc.text}`}>Announcements</h1>
          <p className={tc.textMuted}>Send messages to teams, parents, and track read receipts</p>
        </div>
        <button
          onClick={() => setShowComposeModal(true)}
          className="px-4 py-2 rounded-xl bg-[var(--accent-primary)] text-white font-semibold hover:brightness-110 transition"
        >
          + New Announcement
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
          <p className={`text-sm ${tc.textMuted}`}>Total Sent</p>
          <p className={`text-3xl font-bold ${tc.text}`}>{blasts.length}</p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
          <p className={`text-sm ${tc.textMuted}`}>Avg. Read Rate</p>
          <p className={`text-3xl font-bold text-emerald-500`}>
            {blasts.length > 0 
              ? Math.round(blasts.reduce((sum, b) => sum + b.read_percentage, 0) / blasts.length)
              : 0}%
          </p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
          <p className={`text-sm ${tc.textMuted}`}>Pending Reads</p>
          <p className={`text-3xl font-bold text-amber-500`}>
            {blasts.filter(b => b.read_percentage < 100).length}
          </p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
          <p className={`text-sm ${tc.textMuted}`}>Urgent</p>
          <p className={`text-3xl font-bold text-red-500`}>
            {blasts.filter(b => b.priority === 'urgent').length}
          </p>
        </div>
      </div>
      
      {/* Filter Tabs */}
      <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'all', label: 'All', icon: 'clipboard' },
            { id: 'urgent', label: 'Urgent', icon: '🚨' },
            { id: 'pending', label: 'Pending Reads', icon: '👀' },
            { id: 'payment_reminder', label: 'Payment', icon: 'dollar' },
            { id: 'schedule_change', label: 'Schedule', icon: 'calendar' },
            { id: 'announcement', label: 'General', icon: 'megaphone' },
          ].map(filter => (
            <button
              key={filter.id}
              onClick={() => setFilterType(filter.id)}
              className={`px-4 py-2 rounded-xl font-medium transition ${
                filterType === filter.id
                  ? 'bg-[var(--accent-primary)] text-white'
                  : `${tc.cardBgAlt} ${tc.text} ${tc.hoverBg}`
              }`}
            >
              {filter.icon} {filter.label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Blasts List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-[var(--accent-primary)] border-t-transparent rounded-full mx-auto" />
          <p className={`${tc.textMuted} mt-4`}>Loading announcements...</p>
        </div>
      ) : filteredBlasts.length === 0 ? (
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-12 text-center`}>
          <Megaphone className="w-16 h-16" />
          <p className={`text-xl font-semibold ${tc.text} mt-4`}>No announcements yet</p>
          <p className={tc.textMuted}>Send your first announcement to parents and teams</p>
          <button
            onClick={() => setShowComposeModal(true)}
            className="mt-4 px-6 py-3 rounded-xl bg-[var(--accent-primary)] text-white font-semibold"
          >
            Create Announcement
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredBlasts.map(blast => (
            <div 
              key={blast.id}
              onClick={() => setSelectedBlast(blast)}
              className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4 cursor-pointer hover:border-[var(--accent-primary)]/50 transition`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${getTypeColor(blast.message_type)}`}>
                  {getTypeIcon(blast.message_type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className={`font-semibold ${tc.text}`}>{blast.title}</h3>
                    {blast.priority === 'urgent' && (
                      <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-500 text-white">URGENT</span>
                    )}
                    <span className={`px-2 py-0.5 rounded-full text-xs ${getTypeColor(blast.message_type)}`}>
                      {blast.message_type?.replace('_', ' ')}
                    </span>
                  </div>
                  <p className={`${tc.textSecondary} text-sm line-clamp-2`}>{blast.body}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs">
                    <span className={tc.textMuted}>
                      {new Date(blast.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
                    </span>
                    <span className={tc.textMuted}>by {blast.profiles?.full_name}</span>
                    {blast.teams && (
                      <span className="px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: (blast.teams.color || '#6366F1') + '30', color: blast.teams.color || '#6366F1' }}>
                        {blast.teams.name}
                      </span>
                    )}
                  </div>
                </div>
                
                {/* Read Progress */}
                <div className="text-right min-w-[100px]">
                  <div className={`text-2xl font-bold ${blast.read_percentage === 100 ? 'text-emerald-500' : 'text-amber-500'}`}>
                    {blast.read_percentage}%
                  </div>
                  <p className={`text-xs ${tc.textMuted}`}>
                    {blast.acknowledged_count}/{blast.total_recipients} read
                  </p>
                  <div className="w-full h-2 rounded-full bg-slate-700 mt-2 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${blast.read_percentage === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                      style={{ width: `${blast.read_percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Compose Modal */}
      {showComposeModal && (
        <ComposeBlastModal
          teams={teams}
          onClose={() => setShowComposeModal(false)}
          onSent={() => { loadBlasts(); setShowComposeModal(false) }}
          showToast={showToast}
        />
      )}
      
      {/* Blast Detail Modal */}
      {selectedBlast && (
        <BlastDetailModal
          blast={selectedBlast}
          onClose={() => setSelectedBlast(null)}
          showToast={showToast}
        />
      )}
    </div>
  )
}


export { BlastsPage }
