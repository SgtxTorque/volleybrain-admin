import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { 
  Calendar, MapPin, Clock, Users, ChevronRight, Check, 
  AlertTriangle, Target, MessageCircle, X
} from '../../constants/icons'

function CoachDashboard({ roleContext, navigateToTeamWall, showToast, onNavigate }) {
  const { profile } = useAuth()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const [loading, setLoading] = useState(true)
  const [teams, setTeams] = useState([])
  const [upcomingEvents, setUpcomingEvents] = useState([])
  const [todayEvents, setTodayEvents] = useState([])
  const [rsvpSummary, setRsvpSummary] = useState({})
  const [recentActivity, setRecentActivity] = useState([])
  const [selectedEventDetail, setSelectedEventDetail] = useState(null)
  const [selectedTeamFilter, setSelectedTeamFilter] = useState('all')

  useEffect(() => {
    if (roleContext?.coachInfo?.team_coaches?.length > 0) {
      loadCoachData()
    } else {
      setLoading(false)
    }
  }, [roleContext])

  async function loadCoachData() {
    setLoading(true)
    try {
      let teamIds = roleContext.coachInfo.team_coaches.map(tc => tc.team_id).filter(Boolean)
      console.log('Coach Dashboard - Team IDs from roleContext:', teamIds)
      
      if (teamIds.length === 0) {
        // Try to get team IDs directly from team_coaches table
        const { data: coachTeams, error: ctError } = await supabase
          .from('team_coaches')
          .select('team_id')
          .eq('coach_id', roleContext.coachInfo.id)
        
        console.log('Coach Dashboard - Direct team_coaches query:', coachTeams, 'Error:', ctError)
        
        if (coachTeams?.length > 0) {
          teamIds = coachTeams.map(ct => ct.team_id).filter(Boolean)
        }
      }
      
      console.log('Coach Dashboard - Final Team IDs:', teamIds)

      if (teamIds.length === 0) {
        setLoading(false)
        return
      }

      // Load team details with player counts - simplified query
      const { data: teamData, error: teamError } = await supabase
        .from('teams')
        .select('id, name, color, season_id')
        .in('id', teamIds)
      
      if (teamError) {
        console.error('Coach Dashboard - Teams query error:', teamError)
      }
      console.log('Coach Dashboard - Teams:', teamData)
      setTeams(teamData || [])

      // Load upcoming events - simplified query
      const today = new Date().toISOString().split('T')[0]
      console.log('Coach Dashboard - Today:', today)
      
      const { data: events, error: eventsError } = await supabase
        .from('schedule_events')
        .select('id, title, event_type, event_date, event_time, end_time, venue_name, venue_address, opponent_name, location_type, team_id')
        .in('team_id', teamIds)
        .gte('event_date', today)
        .order('event_date', { ascending: true })
        .order('event_time', { ascending: true })
        .limit(20)
      
      if (eventsError) {
        console.error('Coach Dashboard - Events query error:', eventsError)
      }
      console.log('Coach Dashboard - Events:', events)
      
      // Attach team info to events
      if (events?.length > 0) {
        const eventsWithTeams = events.map(event => ({
          ...event,
          teams: teamData?.find(t => t.id === event.team_id)
        }))
        setUpcomingEvents(eventsWithTeams)
        setTodayEvents(eventsWithTeams.filter(e => e.event_date === today))
      } else {
        setUpcomingEvents([])
        setTodayEvents([])
      }

      // Load RSVP summary
      if (events?.length > 0) {
        const eventIds = events.slice(0, 10).map(e => e.id)
        const { data: rsvps } = await supabase
          .from('event_rsvps')
          .select('event_id, status')
          .in('event_id', eventIds)
        
        const summary = {}
        eventIds.forEach(id => {
          const eventRsvps = (rsvps || []).filter(r => r.event_id === id)
          summary[id] = {
            yes: eventRsvps.filter(r => r.status === 'yes').length,
            no: eventRsvps.filter(r => r.status === 'no').length,
            maybe: eventRsvps.filter(r => r.status === 'maybe').length,
            total: eventRsvps.length
          }
        })
        setRsvpSummary(summary)
      }

      // Load recent posts - simplified query
      const { data: posts, error: postsError } = await supabase
        .from('team_posts')
        .select('id, title, content, post_type, created_at, team_id, author_id, is_pinned')
        .in('team_id', teamIds)
        .order('created_at', { ascending: false })
        .limit(6)
      
      if (postsError) {
        console.error('Coach Dashboard - Posts query error:', postsError)
      }
      
      // Attach team info to posts
      const postsWithTeams = (posts || []).map(post => ({
        ...post,
        teams: teamData?.find(t => t.id === post.team_id)
      }))
      setRecentActivity(postsWithTeams)

    } catch (err) {
      console.error('Error loading coach data:', err)
    }
    setLoading(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className={tc.textSecondary}>Loading coach dashboard...</div>
      </div>
    )
  }

  if (!roleContext?.coachInfo?.team_coaches?.length) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <span className="text-6xl mb-4">Coach</span>
        <h2 className={`text-xl font-bold ${tc.text} mb-2`}>No Teams Assigned</h2>
        <p className={tc.textSecondary}>You haven't been assigned to any teams yet.</p>
        <p className={tc.textMuted}>Contact your league administrator to get assigned.</p>
      </div>
    )
  }

  const totalPlayers = teams.reduce((sum, t) => sum + (t.team_players?.[0]?.count || 0), 0)
  
  // Filter events by selected team
  const filteredEvents = selectedTeamFilter === 'all' 
    ? upcomingEvents 
    : upcomingEvents.filter(e => e.team_id === selectedTeamFilter)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${tc.text}`}>Coach Dashboard Coach</h1>
          <p className={tc.textSecondary}>
            Managing {teams.length} team{teams.length !== 1 ? 's' : ''} • {totalPlayers} players
          </p>
        </div>
        {todayEvents.length > 0 && (
          <div className="px-4 py-2 bg-emerald-500/20 border border-emerald-500/30 rounded-xl">
            <p className="text-emerald-400 font-medium">
              <Target className="w-4 h-4 inline mr-1" />{todayEvents.length} event{todayEvents.length !== 1 ? 's' : ''} today!
            </p>
          </div>
        )}
      </div>

      {/* My Teams */}
      <div>
        <h2 className={`font-semibold ${tc.text} mb-3 flex items-center gap-2`}>
          <VolleyballIcon className="w-4 h-4" /> My Teams
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {teams.map(team => {
            const coachRole = roleContext.coachInfo.team_coaches.find(tc => tc.team_id === team.id)?.role
            const nextEvent = upcomingEvents.find(e => e.team_id === team.id)
            const teamTodayEvents = todayEvents.filter(e => e.team_id === team.id)
            
            return (
              <div 
                key={team.id}
                onClick={() => navigateToTeamWall(team.id)}
                className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5 cursor-pointer hover:border-[var(--accent-primary)]/30 hover:scale-[1.02] transition`}
                style={{ borderLeftWidth: 4, borderLeftColor: team.color }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {team.seasons?.sports?.icon && (
                      <span className="text-xl">{team.seasons.sports.icon}</span>
                    )}
                    <div>
                      <h3 className={`font-bold text-lg ${tc.text}`}>{team.name}</h3>
                      <p className={`text-sm ${tc.textSecondary}`}>
                        {team.team_players?.[0]?.count || 0} players
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    {coachRole === 'head' && (
                      <span className="px-2 py-0.5 bg-[var(--accent-primary)]/20 text-[var(--accent-primary)] text-xs rounded-full font-medium">
                        Head
                      </span>
                    )}
                    {teamTodayEvents.length > 0 && (
                      <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded-full font-medium">
                        {teamTodayEvents.length} today
                      </span>
                    )}
                  </div>
                </div>
                
                {nextEvent ? (
                  <div className={`p-3 rounded-lg ${tc.cardBgAlt}`}>
                    <p className={`text-xs ${tc.textMuted} uppercase tracking-wider mb-1`}>Next Event</p>
                    <p className={`font-medium ${tc.text}`}>
                      {nextEvent.event_type === 'practice' && 'practice'}
                      {nextEvent.event_type === 'game' && '🏆'}
                      {nextEvent.event_type === 'tournament' && <Target className="w-4 h-4 inline" />}
                      {' '}{nextEvent.title || nextEvent.event_type}
                    </p>
                    <p className={`text-sm ${tc.textSecondary}`}>
                      {new Date(nextEvent.event_date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                      {nextEvent.event_time && ` at ${formatTime12(nextEvent.event_time)}`}
                    </p>
                  </div>
                ) : (
                  <div className={`p-3 rounded-lg ${tc.cardBgAlt}`}>
                    <p className={`text-sm ${tc.textMuted}`}>No upcoming events</p>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* At a Glance - Horizontal Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className={`${tc.cardBg} border ${tc.border} rounded-xl p-4 text-center`}>
          <p className="text-3xl font-bold text-[var(--accent-primary)]">{teams.length}</p>
          <p className={`text-sm ${tc.textMuted}`}>Teams</p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-xl p-4 text-center`}>
          <p className="text-3xl font-bold text-[var(--accent-primary)]">{totalPlayers}</p>
          <p className={`text-sm ${tc.textMuted}`}>Players</p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-xl p-4 text-center`}>
          <p className="text-3xl font-bold text-emerald-400">{todayEvents.length}</p>
          <p className={`text-sm ${tc.textMuted}`}>Today</p>
        </div>
        <div className={`${tc.cardBg} border ${tc.border} rounded-xl p-4 text-center`}>
          <p className="text-3xl font-bold text-blue-400">{upcomingEvents.length}</p>
          <p className={`text-sm ${tc.textMuted}`}>Upcoming</p>
        </div>
      </div>

      {/* Quick Actions - Horizontal */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button 
          onClick={() => teams[0] && navigateToTeamWall(teams[0].id)}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <Megaphone className="w-6 h-6" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>New Post</p>
            <p className={`text-xs ${tc.textMuted}`}>Team update</p>
          </div>
        </button>
        <button 
          onClick={() => onNavigate('attendance')}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <CheckSquare className="w-6 h-6" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Attendance</p>
            <p className={`text-xs ${tc.textMuted}`}>Take roll</p>
          </div>
        </button>
        <button 
          onClick={() => onNavigate('schedule')}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <Calendar className="w-8 h-8" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Schedule</p>
            <p className={`text-xs ${tc.textMuted}`}>All events</p>
          </div>
        </button>
        <button 
          onClick={() => teams[0] && navigateToTeamWall(teams[0].id)}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <ClipboardList className="w-7 h-7" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Roster</p>
            <p className={`text-xs ${tc.textMuted}`}>View players</p>
          </div>
        </button>
      </div>

      {/* Today's Events Alert */}
      {todayEvents.length > 0 && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-5">
          <h3 className="font-semibold text-emerald-400 mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 inline mr-1" />Today's Events
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {todayEvents.map(event => (
              <div 
                key={event.id} 
                className={`p-3 rounded-xl ${tc.cardBg} cursor-pointer hover:scale-[1.02] transition`}
                onClick={() => setSelectedEventDetail(event)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`font-medium ${tc.text}`}>
                      {event.event_type === 'practice' && 'practice'}
                      {event.event_type === 'game' && '🏆'}
                      {event.event_type === 'tournament' && <Target className="w-4 h-4 inline" />}
                      {' '}{event.title || event.event_type}
                    </p>
                    <p className="text-sm text-emerald-400">
                      {event.event_time && formatTime12(event.event_time)}
                      {event.venue_name && ` • ${event.venue_name}`}
                    </p>
                  </div>
                  <span 
                    className="px-2 py-0.5 rounded-full text-xs font-medium"
                    style={{ 
                      background: `${event.teams?.color || '#EAB308'}20`,
                      color: event.teams?.color || '#EAB308'
                    }}
                  >
                    {event.teams?.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Schedule with Team Filter */}
      <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className={`font-semibold ${tc.text} flex items-center gap-2`}>
            <Calendar className="w-5 h-5" /> Upcoming Schedule
          </h2>
          <div className="flex items-center gap-2">
            {/* Team Filter */}
            {teams.length > 1 && (
              <select
                value={selectedTeamFilter}
                onChange={(e) => setSelectedTeamFilter(e.target.value)}
                className={`text-sm px-3 py-1.5 rounded-lg ${tc.cardBgAlt} ${tc.text} border ${tc.border}`}
              >
                <option value="all">All Teams</option>
                {teams.map(team => (
                  <option key={team.id} value={team.id}>{team.name}</option>
                ))}
              </select>
            )}
            <button 
              onClick={() => onNavigate('schedule')}
              className="text-sm text-[var(--accent-primary)] hover:underline"
            >
              View All →
            </button>
          </div>
        </div>
        
        {filteredEvents.length > 0 ? (
          <div className="space-y-3">
            {filteredEvents.slice(0, 8).map(event => {
              const eventDate = new Date(event.event_date)
              const isToday = eventDate.toDateString() === new Date().toDateString()
              const rsvp = rsvpSummary[event.id]
              
              return (
                <div 
                  key={event.id}
                  className={`flex items-center gap-4 p-3 rounded-xl ${tc.cardBgAlt} cursor-pointer hover:scale-[1.01] transition ${isToday ? 'ring-2 ring-green-500/50' : ''}`}
                  onClick={() => setSelectedEventDetail(event)}
                >
                  <div 
                    className="w-14 h-14 rounded-xl flex flex-col items-center justify-center text-xs font-bold"
                    style={{ 
                      background: `${event.teams?.color || '#EAB308'}20`,
                      color: event.teams?.color || '#EAB308'
                    }}
                  >
                    <span>{eventDate.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                    <span className="text-lg">{eventDate.getDate()}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className={`font-medium ${tc.text}`}>
                        {event.event_type === 'practice' && 'practice'}
                        {event.event_type === 'game' && '🏆'}
                        {event.event_type === 'tournament' && <Target className="w-4 h-4 inline" />}
                        {event.event_type === 'meeting' && <ClipboardList className="w-4 h-4 inline" />}
                        {' '}{event.title || event.event_type}
                      </span>
                      {isToday && <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded-full">Today</span>}
                    </div>
                    <p className={`text-sm ${tc.textSecondary}`}>
                      {event.event_time && formatTime12(event.event_time)}
                      {event.venue_name && ` • ${event.venue_name}`}
                    </p>
                    <div className="flex items-center gap-2">
                      {event.teams?.seasons?.sports?.icon && (
                        <span className="text-xs">{event.teams.seasons.sports.icon}</span>
                      )}
                      <p className="text-xs" style={{ color: event.teams?.color || '#EAB308' }}>
                        {event.teams?.name}
                      </p>
                    </div>
                  </div>
                  {rsvp && (
                    <div className="text-right">
                      <p className="text-emerald-400 text-sm font-medium flex items-center gap-1"><Check className="w-4 h-4 inline" /> {rsvp.yes}</p>
                      <p className={`text-xs ${tc.textMuted}`}>{rsvp.total} RSVPs</p>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <Calendar className="w-12 h-12" />
            <p className={`${tc.textSecondary} mt-2`}>No upcoming events</p>
          </div>
        )}
      </div>

      {/* Recent Activity */}
      {recentActivity.length > 0 && (
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
          <h2 className={`font-semibold ${tc.text} mb-4 flex items-center gap-2`}>
            <span>📰</span> Recent Team Activity
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentActivity.map(post => (
              <div 
                key={post.id}
                onClick={() => navigateToTeamWall(post.team_id)}
                className={`p-4 rounded-xl ${tc.cardBgAlt} cursor-pointer hover:scale-[1.01] transition`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {post.teams?.seasons?.sports?.icon && (
                      <span className="text-sm">{post.teams.seasons.sports.icon}</span>
                    )}
                    <span 
                      className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{ 
                        background: `${post.teams?.color || '#EAB308'}20`,
                        color: post.teams?.color || '#EAB308'
                      }}
                    >
                      {post.teams?.name}
                    </span>
                  </div>
                  <span className={`text-xs ${tc.textMuted}`}>
                    {new Date(post.created_at).toLocaleDateString()}
                  </span>
                </div>
                <h4 className={`font-medium ${tc.text}`}>{post.title}</h4>
                <p className={`text-sm ${tc.textSecondary} line-clamp-2`}>{post.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Event Detail Modal */}
      {selectedEventDetail && (
        <EventDetailModal
          event={selectedEventDetail}
          teams={teams}
          venues={[]}
          onClose={() => setSelectedEventDetail(null)}
          onUpdate={() => {}}
          onDelete={() => {}}
          activeView="coach"
        />
      )}
    </div>
  )
}

// ============================================

export { CoachDashboard }
