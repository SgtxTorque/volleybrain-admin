import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useSport } from '../../contexts/SportContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { setRegistrationPrefillData } from '../../lib/registration-prefill'
import { 
  Calendar, MapPin, Clock, Users, DollarSign, ChevronRight, 
  Check, AlertTriangle, Plus, RefreshCw, X, ExternalLink
} from '../../constants/icons'

function ParentDashboard({ roleContext, navigateToTeamWall, showToast, onNavigate }) {
  const { profile } = useAuth()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  const { selectedSport } = useSport()
  
  const [loading, setLoading] = useState(true)
  const [upcomingEvents, setUpcomingEvents] = useState([])
  const [payments, setPayments] = useState([])
  const [recentPosts, setRecentPosts] = useState([])
  const [playerDetails, setPlayerDetails] = useState([])
  const [selectedEventDetail, setSelectedEventDetail] = useState(null)
  const [teams, setTeams] = useState([])
  
  // New state for registration features
  const [registrationData, setRegistrationData] = useState([])
  const [openSeasons, setOpenSeasons] = useState([])
  const [showAddChildModal, setShowAddChildModal] = useState(false)
  const [showReRegisterModal, setShowReRegisterModal] = useState(null)
  
  // Helper to generate GitHub Pages registration URL
  function getRegistrationUrl(season) {
    const orgSlug = season.organizations?.slug || 'black-hornets'
    const registrationBaseUrl = season.organizations?.settings?.registration_url || 'https://sgtxtorque.github.io/volleyball-registration'
    return `${registrationBaseUrl}?org=${orgSlug}&season=${season.id}`
  }

  useEffect(() => {
    if (roleContext?.children?.length > 0) {
      loadParentData()
    } else {
      setLoading(false)
      // Still load open seasons even if no children yet
      loadOpenSeasons()
    }
  }, [roleContext])

  async function loadOpenSeasons() {
    try {
      // Get organizations the parent has players in (or any open registrations)
      const parentEmail = profile?.email
      if (!parentEmail) return
      
      // First get org IDs from existing players
      const playerIds = roleContext?.children?.map(c => c.id) || []
      let orgIds = []
      
      if (playerIds.length > 0) {
        const { data: playerSeasons } = await supabase
          .from('players')
          .select('season_id, seasons(organization_id)')
          .in('id', playerIds)
        
        orgIds = [...new Set((playerSeasons || []).map(p => p.seasons?.organization_id).filter(Boolean))]
      }
      
      // Get seasons with open registration
      const now = new Date().toISOString()
      let query = supabase
        .from('seasons')
        .select('*, sports(name, icon), organizations(id, name, logo_url, slug, settings)')
        .lte('registration_opens', now)
        .or(`registration_closes.is.null,registration_closes.gte.${now}`)
        .in('status', ['upcoming', 'active'])
        .order('start_date', { ascending: true })
      
      // If we have org IDs, filter to those orgs (otherwise show all open)
      if (orgIds.length > 0) {
        query = query.in('organization_id', orgIds)
      }
      
      const { data: seasons } = await query
      
      // Filter out seasons player is already registered for
      const registeredSeasonIds = (roleContext?.children || []).map(c => c.season_id)
      const availableSeasons = (seasons || []).filter(s => !registeredSeasonIds.includes(s.id))
      
      setOpenSeasons(availableSeasons)
    } catch (err) {
      console.error('Error loading open seasons:', err)
    }
  }

  async function loadParentData() {
    setLoading(true)
    try {
      const playerIds = roleContext.children.map(c => c.id)
      console.log('Parent Dashboard - Player IDs:', playerIds)
      
      // Load detailed player info with registration status
      const { data: players, error: playersError } = await supabase
        .from('players')
        .select(`
          id, first_name, last_name, photo_url, jersey_number, season_id,
          birth_date, grade, gender, school, parent_name, parent_email, parent_phone,
          registrations(id, status, created_at, approved_at)
        `)
        .in('id', playerIds)
      
      if (playersError) {
        console.error('Parent Dashboard - Players query error:', playersError)
      }
      console.log('Parent Dashboard - Players:', players)
      setPlayerDetails(players || [])

      // Load season info for each player
      const seasonIds = [...new Set((players || []).map(p => p.season_id).filter(Boolean))]
      if (seasonIds.length > 0) {
        const { data: seasons } = await supabase
          .from('seasons')
          .select('id, name, status, start_date, end_date, sports(name, icon), organizations(id, name)')
          .in('id', seasonIds)
        
        // Load payments for each player
        const { data: allPayments } = await supabase
          .from('payments')
          .select('*')
          .in('player_id', playerIds)
        
        // Build registration data with all info
        const regData = (players || []).map(player => {
          const season = seasons?.find(s => s.id === player.season_id)
          const playerPayments = (allPayments || []).filter(p => p.player_id === player.id)
          const totalFees = playerPayments.reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0)
          const totalPaid = playerPayments.filter(p => p.paid).reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0)
          
          return {
            ...player,
            season,
            payments: playerPayments,
            totalFees,
            totalPaid,
            balanceDue: totalFees - totalPaid,
            registrationStatus: player.registrations?.[0]?.status || 'unknown'
          }
        })
        
        setRegistrationData(regData)
      }

      // Query team_players directly to get team IDs
      const { data: teamPlayerLinks, error: tpError } = await supabase
        .from('team_players')
        .select('team_id')
        .in('player_id', playerIds)
      
      if (tpError) {
        console.error('Parent Dashboard - Team players query error:', tpError)
      }
      console.log('Parent Dashboard - Team Player Links:', teamPlayerLinks)
      
      const teamIds = [...new Set((teamPlayerLinks || []).map(tp => tp.team_id).filter(Boolean))]
      console.log('Parent Dashboard - Team IDs:', teamIds)

      // Load upcoming events for all teams
      if (teamIds.length > 0) {
        const today = new Date().toISOString().split('T')[0]
        console.log('Parent Dashboard - Today:', today)
        
        const { data: events, error: eventsError } = await supabase
          .from('schedule_events')
          .select('id, title, event_type, event_date, event_time, end_time, venue_name, venue_address, opponent_name, location_type, team_id')
          .in('team_id', teamIds)
          .gte('event_date', today)
          .order('event_date', { ascending: true })
          .order('event_time', { ascending: true })
          .limit(15)
        
        if (eventsError) {
          console.error('Parent Dashboard - Events query error:', eventsError)
        }
        console.log('Parent Dashboard - Events:', events)
        
        // Load team info separately
        if (events?.length > 0) {
          const eventTeamIds = [...new Set(events.map(e => e.team_id))]
          const { data: teamsData } = await supabase
            .from('teams')
            .select('id, name, color')
            .in('id', eventTeamIds)
          
          // Save teams for EventDetailModal
          setTeams(teamsData || [])
          
          // Attach team info to events
          const eventsWithTeams = events.map(event => ({
            ...event,
            teams: teamsData?.find(t => t.id === event.team_id)
          }))
          setUpcomingEvents(eventsWithTeams)
        } else {
          setUpcomingEvents([])
        }
      } else {
        console.log('Parent Dashboard - No team IDs found, skipping events query')
        setUpcomingEvents([])
      }

      // Load payments for parent's players - simplified
      if (playerIds.length > 0) {
        const { data: paymentData, error: paymentError } = await supabase
          .from('payments')
          .select('id, amount, paid, due_date, description, player_id, created_at')
          .in('player_id', playerIds)
          .order('created_at', { ascending: false })
          .limit(10)
        
        if (paymentError) {
          console.error('Parent Dashboard - Payments query error:', paymentError)
        }
        
        // Attach player info
        const paymentsWithPlayers = (paymentData || []).map(payment => ({
          ...payment,
          players: players?.find(p => p.id === payment.player_id)
        }))
        setPayments(paymentsWithPlayers)
      }

      // Load recent posts from teams - simplified
      if (teamIds.length > 0) {
        const { data: posts, error: postsError } = await supabase
          .from('team_posts')
          .select('id, title, content, post_type, created_at, team_id, is_pinned')
          .in('team_id', teamIds)
          .order('created_at', { ascending: false })
          .limit(6)
        
        if (postsError) {
          console.error('Parent Dashboard - Posts query error:', postsError)
        }
        
        // Load team info for posts
        if (posts?.length > 0) {
          const postTeamIds = [...new Set(posts.map(p => p.team_id))]
          const { data: teamsData } = await supabase
            .from('teams')
            .select('id, name, color')
            .in('id', postTeamIds)
          
          const postsWithTeams = posts.map(post => ({
            ...post,
            teams: teamsData?.find(t => t.id === post.team_id)
          }))
          setRecentPosts(postsWithTeams)
        } else {
          setRecentPosts([])
        }
      }

      // Load open seasons
      await loadOpenSeasons()

    } catch (err) {
      console.error('Error loading parent data:', err)
    }
    setLoading(false)
  }

  // Calculate totals
  const totalDue = payments.filter(p => !p.paid).reduce((sum, p) => sum + (p.amount || 0), 0)

  // Group players by sport for better organization
  const playersBySport = playerDetails.reduce((acc, player) => {
    const sportName = player.seasons?.sports?.name || 'Other'
    const sportIcon = player.seasons?.sports?.icon || '🏅'
    if (!acc[sportName]) {
      acc[sportName] = { icon: sportIcon, players: [] }
    }
    acc[sportName].players.push(player)
    return acc
  }, {})

  // Get status badge color
  function getStatusBadge(status) {
    switch(status) {
      case 'approved': return { bg: 'bg-blue-500/20', text: 'text-blue-400', label: 'Approved' }
      case 'rostered': return { bg: 'bg-emerald-500/20', text: 'text-emerald-400', label: 'On Roster' }
      case 'pending': case 'submitted': case 'new': return { bg: 'bg-[var(--accent-primary)]/20', text: 'text-[var(--accent-primary)]', label: 'Pending Review' }
      case 'waitlist': return { bg: 'bg-amber-500/20', text: 'text-amber-400', label: 'Waitlist' }
      case 'withdrawn': return { bg: 'bg-red-500/20', text: 'text-red-400', label: 'Denied' }
      default: return { bg: 'bg-gray-500/20', text: 'text-gray-400', label: status || 'Unknown' }
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className={tc.textSecondary}>Loading your dashboard...</div>
      </div>
    )
  }

  if (!roleContext?.children?.length) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <span className="text-6xl mb-4">Parent</span>
          <h2 className={`text-xl font-bold ${tc.text} mb-2`}>Welcome!</h2>
          <p className={tc.textSecondary}>You haven't registered any players yet.</p>
          <p className={`${tc.textMuted} mb-6`}>Get started by registering for an open season below.</p>
        </div>
        
        {/* Show open seasons even with no children */}
        {openSeasons.length > 0 && (
          <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
            <h2 className={`font-semibold ${tc.text} mb-4 flex items-center gap-2`}>
              <VolleyballIcon className="w-4 h-4" /> Open Registrations
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {openSeasons.map(season => (
                <div key={season.id} className={`${tc.cardBgAlt} rounded-xl p-4 flex items-center gap-4`}>
                  <div className="w-14 h-14 rounded-xl bg-[var(--accent-primary)]/20 flex items-center justify-center text-2xl">
                    {season.sports?.icon || '🏅'}
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold ${tc.text}`}>{season.name}</p>
                    <p className={`text-sm ${tc.textSecondary}`}>{season.organizations?.name}</p>
                    <p className={`text-xs ${tc.textMuted}`}>
                      {season.start_date && `Starts ${new Date(season.start_date).toLocaleDateString()}`}
                    </p>
                  </div>
                  <a 
                    href={getRegistrationUrl(season)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-[var(--accent-primary)] text-white rounded-xl font-semibold hover:brightness-110 transition"
                  >
                    Register →
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${tc.text}`}>Welcome back! 👋</h1>
          <p className={tc.textSecondary}>Here's what's happening with your players</p>
        </div>
        <div className="flex gap-3">
          {totalDue > 0 && (
            <button 
              onClick={() => onNavigate('payments')}
              className="px-4 py-2 bg-red-500/20 border border-red-500/30 rounded-xl hover:bg-red-500/30 transition"
            >
              <p className="text-red-400 font-medium text-sm"><DollarSign className="w-4 h-4 inline" /> ${totalDue.toFixed(2)} Due</p>
            </button>
          )}
        </div>
      </div>

      {/* Registration Status Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className={`font-semibold ${tc.text} flex items-center gap-2`}>
            <ClipboardList className="w-5 h-5" /> Registration Status
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {registrationData.map(player => {
            const statusBadge = getStatusBadge(player.registrationStatus)
            return (
              <div 
                key={player.id}
                className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4 hover:border-[var(--accent-primary)]/50 transition`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {player.photo_url ? (
                      <img src={player.photo_url} alt={player.first_name} className="w-12 h-12 rounded-xl object-cover" />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-[var(--accent-primary)]/20 flex items-center justify-center text-lg font-bold text-[var(--accent-primary)]">
                        {player.first_name?.[0]}{player.last_name?.[0]}
                      </div>
                    )}
                    <div>
                      <h3 className={`font-semibold ${tc.text}`}>{player.first_name} {player.last_name}</h3>
                      <p className={`text-xs ${tc.textMuted}`}>{player.season?.sports?.icon} {player.season?.name}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusBadge.bg} ${statusBadge.text}`}>
                    {statusBadge.label}
                  </span>
                </div>
                
                {/* Payment Summary for this player */}
                {player.totalFees > 0 && (
                  <div className={`${tc.cardBgAlt} rounded-xl p-3 mt-2`}>
                    <div className="flex justify-between text-sm">
                      <span className={tc.textMuted}>Total Fees</span>
                      <span className={tc.text}>${player.totalFees.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className={tc.textMuted}>Paid</span>
                      <span className="text-emerald-400">${player.totalPaid.toFixed(2)}</span>
                    </div>
                    {player.balanceDue > 0 && (
                      <div className="flex justify-between text-sm font-medium pt-2 border-t border-slate-700/50 mt-2">
                        <span className="text-red-400">Balance Due</span>
                        <span className="text-red-400">${player.balanceDue.toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                )}
                
                {/* View Details */}
                <button 
                  onClick={() => onNavigate(`player-${player.id}`)}
                  className="w-full mt-3 py-2 text-sm text-[var(--accent-primary)] hover:underline"
                >
                  View Details →
                </button>
              </div>
            )
          })}
          
          {/* Add Another Child Card */}
          <div 
            onClick={() => setShowAddChildModal(true)}
            className={`${tc.cardBg} border-2 border-dashed ${tc.border} rounded-2xl p-4 flex flex-col items-center justify-center min-h-[180px] cursor-pointer hover:border-[var(--accent-primary)]/50 hover:bg-[var(--accent-primary)]/5 transition group`}
          >
            <div className="w-14 h-14 rounded-full bg-[var(--accent-primary)]/10 flex items-center justify-center text-3xl text-[var(--accent-primary)] group-hover:scale-110 transition">
              +
            </div>
            <p className={`font-medium ${tc.text} mt-3`}>Add Another Child</p>
            <p className={`text-xs ${tc.textMuted}`}>Register a sibling</p>
          </div>
        </div>
      </div>

      {/* Open Seasons for Re-Registration */}
      {openSeasons.length > 0 && (
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
          <h2 className={`font-semibold ${tc.text} mb-4 flex items-center gap-2`}>
            <span>🔄</span> Register for Another Season
          </h2>
          <p className={`text-sm ${tc.textMuted} mb-4`}>New seasons are open! Register your players to continue playing.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {openSeasons.map(season => (
              <div key={season.id} className={`${tc.cardBgAlt} rounded-xl p-4`}>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[var(--accent-primary)]/20 flex items-center justify-center text-xl">
                    {season.sports?.icon || '🏅'}
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold ${tc.text}`}>{season.name}</p>
                    <p className={`text-sm ${tc.textSecondary}`}>{season.organizations?.name}</p>
                    <p className={`text-xs ${tc.textMuted}`}>
                      {season.start_date && `Starts ${new Date(season.start_date).toLocaleDateString()}`}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  {registrationData.map(player => (
                    <button
                      key={player.id}
                      onClick={() => setShowReRegisterModal({ player, season })}
                      className="flex-1 px-3 py-2 bg-[var(--accent-primary)] text-white rounded-lg text-sm font-medium hover:brightness-110 transition"
                    >
                      Register {player.first_name}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions - Horizontal */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {playerDetails[0]?.team_players?.[0]?.team_id && (
          <button 
            onClick={() => navigateToTeamWall(playerDetails[0].team_players[0].team_id)}
            className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
          >
            <span className="text-2xl">🏠</span>
            <div className="text-left">
              <p className={`font-medium ${tc.text}`}>Team Wall</p>
              <p className={`text-xs ${tc.textMuted}`}>View updates</p>
            </div>
          </button>
        )}
        <button 
          onClick={() => onNavigate('schedule')}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <Calendar className="w-8 h-8" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Full Schedule</p>
            <p className={`text-xs ${tc.textMuted}`}>All events</p>
          </div>
        </button>
        <button 
          onClick={() => onNavigate('payments')}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <DollarSign className="w-7 h-7" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Payments</p>
            <p className={`text-xs ${tc.textMuted}`}>{totalDue > 0 ? `$${totalDue} due` : 'All paid'}</p>
          </div>
        </button>
        <button 
          onClick={() => onNavigate('messages')}
          className={`p-4 rounded-xl ${tc.cardBg} border ${tc.border} ${tc.hoverBg} transition flex items-center gap-3`}
        >
          <MessageCircle className="w-7 h-7" />
          <div className="text-left">
            <p className={`font-medium ${tc.text}`}>Messages</p>
            <p className={`text-xs ${tc.textMuted}`}>Team updates</p>
          </div>
        </button>
      </div>

      {/* Team Updates */}
      {recentPosts.length > 0 && (
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
          <h2 className={`font-semibold ${tc.text} mb-4 flex items-center gap-2`}>
            <Megaphone className="w-4 h-4" /> Team Updates
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentPosts.map(post => (
              <div 
                key={post.id}
                className={`p-4 rounded-xl ${tc.cardBgAlt} cursor-pointer hover:scale-[1.01] transition`}
                onClick={() => navigateToTeamWall(post.team_id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {post.teams?.seasons?.sports?.icon && (
                      <span className="text-sm">{post.teams.seasons.sports.icon}</span>
                    )}
                    <span 
                      className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{ 
                        background: `${post.teams?.color || '#EAB308'}20`,
                        color: post.teams?.color || '#EAB308'
                      }}
                    >
                      {post.teams?.name}
                    </span>
                  </div>
                  <span className={`text-xs ${tc.textMuted}`}>
                    {new Date(post.created_at).toLocaleDateString()}
                  </span>
                </div>
                <h3 className={`font-medium ${tc.text}`}>{post.title}</h3>
                <p className={`text-sm ${tc.textSecondary} line-clamp-2`}>{post.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Schedule & Payments Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Events */}
        <div className={`lg:col-span-2 ${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`font-semibold ${tc.text} flex items-center gap-2`}>
              <Calendar className="w-5 h-5" /> Upcoming Schedule
            </h2>
            <button 
              onClick={() => onNavigate('schedule')}
              className="text-sm text-[var(--accent-primary)] hover:underline"
            >
              View All →
            </button>
          </div>
          {upcomingEvents.length > 0 ? (
            <div className="space-y-3">
              {upcomingEvents.slice(0, 5).map(event => {
                const eventDate = new Date(event.event_date)
                const isToday = eventDate.toDateString() === new Date().toDateString()
                const isTomorrow = eventDate.toDateString() === new Date(Date.now() + 86400000).toDateString()
                
                return (
                  <div 
                    key={event.id}
                    className={`flex items-center gap-4 p-3 rounded-xl ${tc.cardBgAlt} cursor-pointer hover:scale-[1.01] transition`}
                    onClick={() => setSelectedEventDetail(event)}
                  >
                    <div 
                      className="w-14 h-14 rounded-xl flex flex-col items-center justify-center text-xs font-bold"
                      style={{ 
                        background: `${event.teams?.color || '#EAB308'}20`,
                        color: event.teams?.color || '#EAB308'
                      }}
                    >
                      <span>{eventDate.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                      <span className="text-lg">{eventDate.getDate()}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`font-medium ${tc.text}`}>
                          {event.event_type === 'practice' && 'practice'}
                          {event.event_type === 'game' && '🏆'}
                          {event.event_type === 'tournament' && <Target className="w-4 h-4 inline" />}
                          {event.event_type === 'meeting' && <ClipboardList className="w-4 h-4 inline" />}
                          {' '}{event.title || event.event_type}
                        </span>
                        {isToday && <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded-full">Today</span>}
                        {isTomorrow && <span className="px-2 py-0.5 bg-[var(--accent-primary)]/20 text-[var(--accent-primary)] text-xs rounded-full">Tomorrow</span>}
                      </div>
                      <p className={`text-sm ${tc.textSecondary}`}>
                        {event.event_time && formatTime12(event.event_time)}
                        {event.venue_name && ` • ${event.venue_name}`}
                      </p>
                      <div className="flex items-center gap-2">
                        {event.teams?.seasons?.sports?.icon && (
                          <span className="text-xs">{event.teams.seasons.sports.icon}</span>
                        )}
                        <p className="text-xs" style={{ color: event.teams?.color || '#EAB308' }}>
                          {event.teams?.name}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12" />
              <p className={`${tc.textSecondary} mt-2`}>No upcoming events</p>
            </div>
          )}
        </div>

        {/* Payment Summary */}
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`font-semibold ${tc.text} flex items-center gap-2`}>
              <DollarSign className="w-5 h-5" /> Payments
            </h2>
            <button 
              onClick={() => onNavigate('payments')}
              className="text-sm text-[var(--accent-primary)] hover:underline"
            >
              View All →
            </button>
          </div>
          
          {/* Balance Summary */}
          <div className={`p-4 rounded-xl mb-4 ${totalDue > 0 ? 'bg-red-500/10 border border-red-500/30' : 'bg-emerald-500/10 border border-emerald-500/30'}`}>
            <p className={`text-sm ${totalDue > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
              {totalDue > 0 ? 'Balance Due' : 'All Paid!'}
            </p>
            <p className={`text-3xl font-bold ${totalDue > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
              ${totalDue.toFixed(2)}
            </p>
            {totalDue > 0 && (
              <button 
                onClick={() => onNavigate('payments')}
                className="w-full mt-3 py-2 bg-[var(--accent-primary)] text-white rounded-lg font-medium hover:brightness-110 transition"
              >
                Pay Now →
              </button>
            )}
          </div>

          {/* Recent Payments */}
          <p className={`text-xs ${tc.textMuted} uppercase tracking-wider mb-2`}>Recent Activity</p>
          <div className="space-y-2">
            {payments.slice(0, 4).map(payment => (
              <div key={payment.id} className={`flex items-center justify-between p-2 rounded-lg ${tc.cardBgAlt}`}>
                <div className="flex items-center gap-2">
                  {payment.players?.seasons?.sports?.icon && (
                    <span className="text-sm">{payment.players.seasons.sports.icon}</span>
                  )}
                  <div>
                    <p className={`text-sm ${tc.text}`}>{payment.description || 'Payment'}</p>
                    <p className={`text-xs ${tc.textMuted}`}>{payment.players?.first_name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-medium ${payment.paid ? 'text-emerald-400' : 'text-red-400'}`}>
                    ${payment.amount}
                  </p>
                  <p className={`text-xs ${payment.paid ? 'text-emerald-400' : 'text-red-400'}`}>
                    {payment.paid ? '✓ Paid' : 'Due'}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {payments.length === 0 && (
            <p className={`text-sm ${tc.textMuted} text-center py-4`}>No payment records</p>
          )}
        </div>
      </div>

      {/* Event Detail Modal */}
      {selectedEventDetail && (
        <EventDetailModal
          event={selectedEventDetail}
          teams={teams}
          venues={[]}
          onClose={() => setSelectedEventDetail(null)}
          onUpdate={() => {}}
          onDelete={() => {}}
          activeView="parent"
        />
      )}

      {/* Add Another Child Modal */}
      {showAddChildModal && (
        <AddChildModal
          existingChildren={registrationData}
          onClose={() => setShowAddChildModal(false)}
          showToast={showToast}
        />
      )}

      {/* Re-Register Modal */}
      {showReRegisterModal && (
        <ReRegisterModal
          player={showReRegisterModal.player}
          season={showReRegisterModal.season}
          onClose={() => setShowReRegisterModal(null)}
          showToast={showToast}
        />
      )}
    </div>
  )
}

// ============================================

export { ParentDashboard }
