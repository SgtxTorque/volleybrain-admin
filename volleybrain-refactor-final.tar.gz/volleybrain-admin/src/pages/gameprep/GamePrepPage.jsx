import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useSeason } from '../../contexts/SeasonContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { 
  Calendar, Users, MapPin, Clock, Check, AlertTriangle, ChevronRight
} from '../../constants/icons'

function GamePrepPage({ showToast }) {
  const { organization } = useAuth()
  const { selectedSeason } = useSeason()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const [loading, setLoading] = useState(true)
  const [games, setGames] = useState([])
  const [teams, setTeams] = useState([])
  const [selectedTeam, setSelectedTeam] = useState(null)
  const [selectedGame, setSelectedGame] = useState(null)
  const [lineupStatuses, setLineupStatuses] = useState({})

  useEffect(() => {
    loadTeams()
  }, [selectedSeason?.id])

  useEffect(() => {
    if (selectedTeam) loadGames()
  }, [selectedTeam])

  async function loadTeams() {
    if (!selectedSeason?.id) return
    
    try {
      const { data } = await supabase
        .from('teams')
        .select('id, name, color')
        .eq('season_id', selectedSeason.id)
        .order('name')
      
      setTeams(data || [])
      if (data?.length > 0) setSelectedTeam(data[0])
    } catch (err) {
      console.error('Error loading teams:', err)
    }
  }

  async function loadGames() {
    if (!selectedTeam?.id) return
    setLoading(true)
    
    try {
      const today = new Date().toISOString().split('T')[0]
      
      // Load upcoming games
      const { data: gamesData } = await supabase
        .from('schedule_events')
        .select('*')
        .eq('team_id', selectedTeam.id)
        .eq('event_type', 'game')
        .gte('event_date', today)
        .order('event_date', { ascending: true })
        .order('event_time', { ascending: true })
        .limit(20)
      
      setGames(gamesData || [])
      
      // Load lineup statuses for these games
      if (gamesData?.length > 0) {
        const eventIds = gamesData.map(g => g.id)
        const { data: lineups } = await supabase
          .from('game_lineups')
          .select('event_id, is_published, rotation_type')
          .in('event_id', eventIds)
        
        const statusMap = {}
        lineups?.forEach(l => {
          statusMap[l.event_id] = {
            hasLineup: true,
            isPublished: l.is_published,
            rotationType: l.rotation_type
          }
        })
        setLineupStatuses(statusMap)
      }
      
    } catch (err) {
      console.error('Error loading games:', err)
    }
    setLoading(false)
  }

  function getLineupStatus(gameId) {
    const status = lineupStatuses[gameId]
    if (!status) return { label: 'Not Started', color: 'text-slate-400', bg: 'bg-slate-500/20' }
    if (status.isPublished) return { label: 'Published', color: 'text-emerald-500', bg: 'bg-emerald-500/20' }
    return { label: 'Draft', color: 'text-amber-500', bg: 'bg-amber-500/20' }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${tc.text}`}><VolleyballIcon className="w-7 h-7 inline mr-2" />Game Prep</h1>
          <p className={tc.textSecondary}>Build lineups and prepare for upcoming games</p>
        </div>
      </div>

      {/* Team Selector */}
      <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
        <div className="flex items-center gap-4 overflow-x-auto pb-2">
          {teams.map(team => (
            <button
              key={team.id}
              onClick={() => setSelectedTeam(team)}
              className={`px-4 py-2 rounded-xl whitespace-nowrap flex items-center gap-2 transition font-medium ${
                selectedTeam?.id === team.id
                  ? 'text-white shadow-lg'
                  : `${tc.cardBgAlt} ${tc.textSecondary} ${tc.hoverBg}`
              }`}
              style={selectedTeam?.id === team.id ? { backgroundColor: team.color } : {}}
            >
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: team.color }} />
              {team.name}
            </button>
          ))}
        </div>
      </div>

      {/* Games List */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin w-8 h-8 border-2 border-[var(--accent-primary)] border-t-transparent rounded-full" />
        </div>
      ) : games.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {games.map(game => {
            const status = getLineupStatus(game.id)
            const gameDate = new Date(game.event_date)
            const isToday = gameDate.toDateString() === new Date().toDateString()
            const isTomorrow = gameDate.toDateString() === new Date(Date.now() + 86400000).toDateString()
            
            return (
              <div 
                key={game.id}
                className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5 hover:border-[var(--accent-primary)]/50 transition cursor-pointer`}
                onClick={() => setSelectedGame(game)}
              >
                <div className="flex items-start gap-4">
                  {/* Date */}
                  <div 
                    className="w-16 h-16 rounded-xl flex flex-col items-center justify-center text-white"
                    style={{ backgroundColor: selectedTeam?.color || '#6366F1' }}
                  >
                    <span className="text-xs uppercase">{gameDate.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                    <span className="text-2xl font-bold">{gameDate.getDate()}</span>
                  </div>
                  
                  {/* Game Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className={`font-bold ${tc.text}`}>
                        {game.title || `vs ${game.opponent_name || 'TBD'}`}
                      </h3>
                      {isToday && (
                        <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-500">TODAY</span>
                      )}
                      {isTomorrow && (
                        <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-500">TOMORROW</span>
                      )}
                    </div>
                    <p className={`text-sm ${tc.textMuted}`}>
                      {game.event_time && formatTime12(game.event_time)}
                      {game.venue_name && ` • ${game.venue_name}`}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${status.bg} ${status.color}`}>
                        {status.label}
                      </span>
                      {lineupStatuses[game.id]?.rotationType && (
                        <span className={`text-xs ${tc.textMuted}`}>
                          {lineupStatuses[game.id].rotationType}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Action */}
                  <button 
                    className="px-4 py-2 rounded-xl bg-[var(--accent-primary)] text-white font-medium hover:brightness-110 transition"
                    onClick={(e) => { e.stopPropagation(); setSelectedGame(game); }}
                  >
                    {lineupStatuses[game.id] ? 'Edit' : 'Prep'} →
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-12 text-center`}>
          <span className="text-6xl"><VolleyballIcon className="w-16 h-16" /></span>
          <h2 className={`text-xl font-bold ${tc.text} mt-4`}>No Upcoming Games</h2>
          <p className={tc.textMuted}>Schedule some games to start prepping!</p>
        </div>
      )}

      {/* Past Games Section */}
      <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-5`}>
        <h2 className={`font-semibold ${tc.text} mb-4 flex items-center gap-2`}>
          <BarChart3 className="w-5 h-5" /> Recent Game Results
        </h2>
        <div className="text-center py-6">
          <span className="text-4xl">🚧</span>
          <p className={`${tc.textMuted} mt-2`}>Game results will appear here after you record scores</p>
        </div>
      </div>

      {/* Lineup Builder Modal */}
      {selectedGame && selectedTeam && (
        <LineupBuilder
          event={selectedGame}
          team={selectedTeam}
          onClose={() => { setSelectedGame(null); loadGames(); }}
          showToast={showToast}
        />
      )}
    </div>
  )
}


export { GamePrepPage }
