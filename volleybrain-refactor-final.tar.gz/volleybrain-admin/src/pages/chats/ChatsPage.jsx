import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useSeason } from '../../contexts/SeasonContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { 
  Search, MessageCircle, Users, Plus, ChevronRight, X
} from '../../constants/icons'

function ChatsPage({ showToast, activeView, roleContext }) {
  const { organization, profile, user } = useAuth()
  const { selectedSeason } = useSeason()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const [loading, setLoading] = useState(true)
  const [channels, setChannels] = useState([])
  const [teams, setTeams] = useState([])
  const [selectedChannel, setSelectedChannel] = useState(null)
  const [showNewChatModal, setShowNewChatModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterType, setFilterType] = useState('all') // all, team, dm
  
  useEffect(() => {
    if (selectedSeason?.id) loadChats()
  }, [selectedSeason?.id])
  
  async function loadChats() {
    setLoading(true)
    try {
      // Load teams for this season
      const { data: teamsData } = await supabase
        .from('teams')
        .select('*')
        .eq('season_id', selectedSeason.id)
        .order('name')
      setTeams(teamsData || [])
      
      // Load chat channels
      const { data: channelsData } = await supabase
        .from('chat_channels')
        .select(`
          *,
          teams (id, name, color),
          channel_members (id, user_id, display_name, member_role, last_read_at),
          chat_messages (id, content, message_type, created_at, sender_id, profiles:sender_id (full_name))
        `)
        .eq('season_id', selectedSeason.id)
        .eq('is_archived', false)
        .order('updated_at', { ascending: false })
      
      // Process channels with last message and unread count
      const processedChannels = (channelsData || []).map(ch => {
        const lastMessage = ch.chat_messages?.sort((a, b) => 
          new Date(b.created_at) - new Date(a.created_at)
        )[0]
        
        const myMembership = ch.channel_members?.find(m => m.user_id === user?.id)
        const unreadCount = myMembership?.last_read_at 
          ? ch.chat_messages?.filter(m => new Date(m.created_at) > new Date(myMembership.last_read_at)).length || 0
          : ch.chat_messages?.length || 0
        
        return {
          ...ch,
          last_message: lastMessage,
          unread_count: unreadCount,
          my_membership: myMembership
        }
      })
      
      setChannels(processedChannels)
    } catch (err) {
      console.error('Error loading chats:', err)
      showToast?.('Error loading chats', 'error')
    }
    setLoading(false)
  }
  
  async function createTeamChat(teamId) {
    const team = teams.find(t => t.id === teamId)
    if (!team) return
    
    // Check if chat already exists
    const existing = channels.find(c => c.team_id === teamId && c.channel_type === 'team_chat')
    if (existing) {
      setSelectedChannel(existing)
      return
    }
    
    // Create new team chat
    const { data: newChannel, error } = await supabase
      .from('chat_channels')
      .insert({
        season_id: selectedSeason.id,
        team_id: teamId,
        name: `${team.name} Chat`,
        channel_type: 'team_chat',
        created_by: user?.id
      })
      .select()
      .single()
    
    if (error) {
      showToast?.('Error creating chat', 'error')
      return
    }
    
    // Add creator as member
    await supabase.from('channel_members').insert({
      channel_id: newChannel.id,
      user_id: user?.id,
      display_name: profile?.full_name || 'Admin',
      member_role: 'admin',
      can_post: true,
      can_moderate: true
    })
    
    showToast?.('Team chat created!', 'success')
    loadChats()
    setSelectedChannel(newChannel)
  }
  
  // Filter channels
  const filteredChannels = channels.filter(ch => {
    const matchesSearch = !searchQuery || 
      ch.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ch.teams?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesType = filterType === 'all' || 
      (filterType === 'team' && ch.channel_type === 'team_chat') ||
      (filterType === 'dm' && (ch.channel_type === 'dm' || ch.channel_type === 'group_dm'))
    
    return matchesSearch && matchesType
  })
  
  // Group by type
  const teamChats = filteredChannels.filter(c => c.channel_type === 'team_chat' || c.channel_type === 'player_chat')
  const directMessages = filteredChannels.filter(c => c.channel_type === 'dm' || c.channel_type === 'group_dm')
  const announcements = filteredChannels.filter(c => c.channel_type === 'league_announcement')
  
  const getChannelIcon = (type) => {
    switch(type) {
      case 'team_chat': return <Users className="w-6 h-6" />
      case 'player_chat': return <VolleyballIcon className="w-6 h-6" />
      case 'dm': return <MessageCircle className="w-6 h-6" />
      case 'group_dm': return <Users className="w-6 h-6" />
      case 'league_announcement': return <Megaphone className="w-6 h-6" />
      default: return <MessageCircle className="w-6 h-6" />
    }
  }
  
  const formatLastMessageTime = (date) => {
    if (!date) return ''
    const d = new Date(date)
    const now = new Date()
    const diff = now - d
    
    if (diff < 60000) return 'Just now'
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m`
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`
    if (diff < 604800000) return d.toLocaleDateString('en-US', { weekday: 'short' })
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${tc.text}`}>💬 Chats</h1>
          <p className={tc.textMuted}>Team conversations and direct messages</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowNewChatModal(true)}
            className="px-4 py-2 rounded-xl bg-[var(--accent-primary)] text-white font-semibold hover:brightness-110 transition"
          >
            + New Chat
          </button>
        </div>
      </div>
      
      {/* Filters */}
      <div className={`${tc.cardBg} border ${tc.border} rounded-2xl p-4`}>
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="Search chats..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className={`w-full px-4 py-2 rounded-xl ${tc.input}`}
            />
          </div>
          <div className="flex gap-2">
            {['all', 'team', 'dm'].map(type => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-4 py-2 rounded-xl font-medium transition ${
                  filterType === type
                    ? 'bg-[var(--accent-primary)] text-white'
                    : `${tc.cardBgAlt} ${tc.text} ${tc.hoverBg}`
                }`}
              >
                {type === 'all' ? 'All' : type === 'team' ? 'Teams' : 'DMs'}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-[var(--accent-primary)] border-t-transparent rounded-full mx-auto" />
          <p className={`${tc.textMuted} mt-4`}>Loading chats...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat List */}
          <div className={`lg:col-span-1 ${tc.cardBg} border ${tc.border} rounded-2xl overflow-hidden`}>
            <div className={`p-4 border-b ${tc.border}`}>
              <h3 className={`font-semibold ${tc.text}`}>Conversations ({filteredChannels.length})</h3>
            </div>
            <div className="max-h-[600px] overflow-y-auto">
              {/* Team Chats */}
              {teamChats.length > 0 && (
                <div>
                  <div className={`px-4 py-2 ${tc.cardBgAlt}`}>
                    <span className={`text-xs font-semibold uppercase ${tc.textMuted}`}>Team Chats</span>
                  </div>
                  {teamChats.map(channel => (
                    <div
                      key={channel.id}
                      onClick={() => setSelectedChannel(channel)}
                      className={`flex items-center gap-3 p-4 cursor-pointer transition ${
                        selectedChannel?.id === channel.id 
                          ? 'bg-[var(--accent-primary)]/10' 
                          : tc.hoverBg
                      } border-b ${tc.border}`}
                    >
                      <div 
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-xl"
                        style={{ backgroundColor: (channel.teams?.color || '#6366F1') + '30' }}
                      >
                        {getChannelIcon(channel.channel_type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className={`font-semibold ${tc.text} truncate`}>{channel.name}</span>
                          {channel.unread_count > 0 && (
                            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-[var(--accent-primary)] text-white">
                              {channel.unread_count}
                            </span>
                          )}
                        </div>
                        <p className={`text-sm ${tc.textMuted} truncate`}>
                          {channel.last_message?.content || 'No messages yet'}
                        </p>
                        <span className={`text-xs ${tc.textMuted}`}>
                          {formatLastMessageTime(channel.last_message?.created_at)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Direct Messages */}
              {directMessages.length > 0 && (
                <div>
                  <div className={`px-4 py-2 ${tc.cardBgAlt}`}>
                    <span className={`text-xs font-semibold uppercase ${tc.textMuted}`}>Direct Messages</span>
                  </div>
                  {directMessages.map(channel => (
                    <div
                      key={channel.id}
                      onClick={() => setSelectedChannel(channel)}
                      className={`flex items-center gap-3 p-4 cursor-pointer transition ${
                        selectedChannel?.id === channel.id 
                          ? 'bg-[var(--accent-primary)]/10' 
                          : tc.hoverBg
                      } border-b ${tc.border}`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-slate-500/20 flex items-center justify-center text-xl">
                        💬
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className={`font-semibold ${tc.text} truncate`}>{channel.name}</span>
                          {channel.unread_count > 0 && (
                            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-[var(--accent-primary)] text-white">
                              {channel.unread_count}
                            </span>
                          )}
                        </div>
                        <p className={`text-sm ${tc.textMuted} truncate`}>
                          {channel.last_message?.content || 'No messages yet'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {filteredChannels.length === 0 && (
                <div className="text-center py-12">
                  <span className="text-4xl">💬</span>
                  <p className={`${tc.textMuted} mt-4`}>No chats found</p>
                  <button
                    onClick={() => setShowNewChatModal(true)}
                    className="mt-4 px-4 py-2 rounded-xl bg-[var(--accent-primary)]/20 text-[var(--accent-primary)] font-medium"
                  >
                    Start a conversation
                  </button>
                </div>
              )}
            </div>
          </div>
          
          {/* Chat Detail */}
          <div className={`lg:col-span-2 ${tc.cardBg} border ${tc.border} rounded-2xl overflow-hidden`}>
            {selectedChannel ? (
              <ChatDetailPanel 
                channel={selectedChannel} 
                onClose={() => setSelectedChannel(null)}
                onRefresh={loadChats}
                showToast={showToast}
              />
            ) : (
              <div className="h-[600px] flex flex-col items-center justify-center">
                <span className="text-6xl mb-4">💬</span>
                <p className={`text-xl font-semibold ${tc.text}`}>Select a conversation</p>
                <p className={tc.textMuted}>Choose a chat from the list or start a new one</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* New Chat Modal */}
      {showNewChatModal && (
        <NewChatModal
          teams={teams}
          onClose={() => setShowNewChatModal(false)}
          onCreateTeamChat={createTeamChat}
          showToast={showToast}
        />
      )}
    </div>
  )
}


export { ChatsPage }
