import { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { useTheme, useThemeClasses } from '../../contexts/ThemeContext'
import { supabase } from '../../lib/supabase'
import { PlayerCardExpanded } from '../../components/players'
import { 
  ArrowLeft, Calendar, MapPin, Clock, Users, MessageCircle, 
  FileText, Plus, Send, X, ChevronRight, Star, Check
} from '../../constants/icons'

function TeamWallPage({ teamId, showToast, onBack }) {
  const { profile, isAdmin } = useAuth()
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  // Core data
  const [team, setTeam] = useState(null)
  const [roster, setRoster] = useState([])
  const [coaches, setCoaches] = useState([])
  const [upcomingEvents, setUpcomingEvents] = useState([])
  const [loading, setLoading] = useState(true)
  
  // Posts/Feed
  const [posts, setPosts] = useState([])
  const [documents, setDocuments] = useState([])
  const [activeTab, setActiveTab] = useState('feed')
  
  // Modals
  const [showNewPostModal, setShowNewPostModal] = useState(false)
  const [showUploadDocModal, setShowUploadDocModal] = useState(false)
  const [selectedPlayer, setSelectedPlayer] = useState(null)
  const [selectedCoach, setSelectedCoach] = useState(null)
  const [expandedPost, setExpandedPost] = useState(null)
  const [selectedEvent, setSelectedEvent] = useState(null)
  
  // User permissions - use isAdmin from auth context
  const isCoachOrAdmin = isAdmin || profile?.role === 'coach'

  // Debug: Log permission info
  useEffect(() => {
    console.log('Permission check:', { isAdmin, profileRole: profile?.role, isCoachOrAdmin })
  }, [isAdmin, profile, isCoachOrAdmin])

  useEffect(() => {
    if (teamId) loadTeamData()
  }, [teamId])

  async function loadTeamData() {
    setLoading(true)
    try {
      // Load team details
      const { data: teamData } = await supabase
        .from('teams')
        .select('*, seasons(name, status)')
        .eq('id', teamId)
        .single()
      setTeam(teamData)

      // Load roster
      const { data: rosterData } = await supabase
        .from('team_players')
        .select('*, players(id, first_name, last_name, jersey_number, position, photo_url, grade)')
        .eq('team_id', teamId)
      setRoster(rosterData?.map(tp => tp.players).filter(Boolean) || [])

      // Load coaches - two-step query for reliability
      const { data: teamCoachLinks, error: linkError } = await supabase
        .from('team_coaches')
        .select('coach_id, role')
        .eq('team_id', teamId)
      
      console.log('Team coach links:', teamCoachLinks, 'Error:', linkError)
      
      if (teamCoachLinks && teamCoachLinks.length > 0) {
        const coachIds = teamCoachLinks.map(tc => tc.coach_id)
        const { data: coachDetails, error: coachError } = await supabase
          .from('coaches')
          .select('*')
          .in('id', coachIds)
        
        console.log('Coach details:', coachDetails, 'Error:', coachError)
        
        // Merge role info with coach details
        const mappedCoaches = (coachDetails || []).map(coach => {
          const link = teamCoachLinks.find(tc => tc.coach_id === coach.id)
          return {
            ...coach,
            assignment_role: link?.role || 'coach'
          }
        })
        console.log('Final coaches:', mappedCoaches)
        setCoaches(mappedCoaches)
      } else {
        setCoaches([])
      }

      // Load upcoming events (next 5)
      const today = new Date().toISOString().split('T')[0]
      console.log('Loading events for team:', teamId, 'from date:', today)
      const { data: eventsData, error: eventsError } = await supabase
        .from('schedule_events')
        .select('*')
        .eq('team_id', teamId)
        .gte('event_date', today)
        .order('event_date', { ascending: true })
        .order('event_time', { ascending: true })
        .limit(5)
      console.log('Events loaded:', eventsData, 'Error:', eventsError)
      setUpcomingEvents(eventsData || [])

      // Load posts
      const { data: postsData } = await supabase
        .from('team_posts')
        .select('*, profiles(id, full_name, avatar_url)')
        .eq('team_id', teamId)
        .eq('is_published', true)
        .order('is_pinned', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(20)
      setPosts(postsData || [])

      // Load documents
      const { data: docsData } = await supabase
        .from('team_documents')
        .select('*, profiles:uploaded_by(full_name)')
        .eq('team_id', teamId)
        .eq('is_archived', false)
        .order('created_at', { ascending: false })
      setDocuments(docsData || [])

    } catch (err) {
      console.error('Error loading team data:', err)
    }
    setLoading(false)
  }

  async function createPost(postData) {
    try {
      const { error } = await supabase.from('team_posts').insert({
        team_id: teamId,
        author_id: profile.id,
        ...postData
      })
      if (error) throw error
      showToast('Post created!', 'success')
      setShowNewPostModal(false)
      loadTeamData()
    } catch (err) {
      showToast('Error: ' + err.message, 'error')
    }
  }

  async function toggleReaction(postId, reactionType = 'like') {
    try {
      // Check if user already reacted
      const { data: existing } = await supabase
        .from('team_post_reactions')
        .select('id')
        .eq('post_id', postId)
        .eq('user_id', profile.id)
        .single()

      if (existing) {
        // Remove reaction
        await supabase.from('team_post_reactions').delete().eq('id', existing.id)
      } else {
        // Add reaction
        await supabase.from('team_post_reactions').insert({
          post_id: postId,
          user_id: profile.id,
          reaction_type: reactionType
        })
      }
      loadTeamData()
    } catch (err) {
      console.error('Reaction error:', err)
    }
  }

  async function addComment(postId, content) {
    try {
      await supabase.from('team_post_comments').insert({
        post_id: postId,
        author_id: profile.id,
        content
      })
      loadTeamData()
    } catch (err) {
      showToast('Error adding comment', 'error')
    }
  }

  async function deletePost(postId) {
    if (!confirm('Delete this post?')) return
    try {
      await supabase.from('team_posts').delete().eq('id', postId)
      showToast('Post deleted', 'success')
      loadTeamData()
    } catch (err) {
      showToast('Error deleting post', 'error')
    }
  }

  async function uploadDocument(docData) {
    try {
      await supabase.from('team_documents').insert({
        team_id: teamId,
        uploaded_by: profile.id,
        ...docData
      })
      showToast('Document uploaded!', 'success')
      setShowUploadDocModal(false)
      loadTeamData()
    } catch (err) {
      showToast('Error: ' + err.message, 'error')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[var(--accent-primary)] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className={tc.textSecondary}>Loading team...</p>
        </div>
      </div>
    )
  }

  if (!team) {
    return (
      <div className="text-center py-20">
        <span className="text-6xl"><VolleyballIcon className="w-16 h-16" /></span>
        <h2 className={`text-xl font-bold ${tc.text} mt-4`}>Team not found</h2>
        <button onClick={onBack} className="mt-4 text-[var(--accent-primary)] hover:underline">← Go back</button>
      </div>
    )
  }

  const teamColor = team.color || '#EAB308'

  return (
    <div className="min-h-screen relative">
      {/* Watermark Background */}
      {team.logo_url && (
        <div 
          className="absolute inset-0 opacity-5 bg-no-repeat bg-center pointer-events-none"
          style={{ 
            backgroundImage: `url(${team.logo_url})`,
            backgroundSize: '60%',
          }}
        />
      )}
      
      {/* Content */}
      <div className="relative z-10 space-y-6">
        {/* Back Button */}
        {onBack && (
          <button onClick={onBack} className={`${tc.textSecondary} hover:${tc.text} flex items-center gap-2`}>
            ← Back to Teams
          </button>
        )}

        {/* Team Header Card */}
        <div 
          className="rounded-2xl p-6 relative overflow-hidden"
          style={{ 
            background: `linear-gradient(135deg, ${teamColor}20 0%, ${teamColor}05 100%)`,
            borderLeft: `4px solid ${teamColor}`
          }}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-5">
              {/* Team Logo/Avatar */}
              {team.logo_url ? (
                <img src={team.logo_url} alt="" className="w-20 h-20 rounded-xl object-cover" style={{ border: `3px solid ${teamColor}` }} />
              ) : (
                <div 
                  className="w-20 h-20 rounded-xl flex items-center justify-center"
                  style={{ background: `${teamColor}30`, border: `3px solid ${teamColor}` }}
                >
                  <VolleyballIcon className="w-10 h-10" style={{ color: teamColor }} />
                </div>
              )}
              
              <div>
                <h1 className={`text-3xl font-bold ${tc.text}`} style={{ color: teamColor }}>
                  {team.name}
                </h1>
                {team.motto && <p className={`${tc.textSecondary} italic mt-1`}>"{team.motto}"</p>}
                <div className="flex items-center gap-4 mt-2">
                  <span className={`${tc.textSecondary} text-sm flex items-center gap-1`}>
                    <Calendar className="w-4 h-4" /> {team.seasons?.name || 'Current Season'}
                  </span>
                  <span className={`${tc.textSecondary} text-sm flex items-center gap-1`}>
                    <Users className="w-4 h-4" /> {roster.length} Players
                  </span>
                  <span className={`${tc.textSecondary} text-sm flex items-center gap-1`}>
                    <UserCog className="w-4 h-4" /> {coaches.length} Coaches
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  const url = `${window.location.origin}${window.location.pathname}#/team/${teamId}`
                  navigator.clipboard.writeText(url)
                  showToast('Link copied! Share with parents.', 'success')
                }}
                className={`px-3 py-2 rounded-xl text-sm ${tc.cardBgAlt} ${tc.textSecondary} hover:${tc.text} transition`}
                title="Copy shareable link"
              >
                🔗 Copy Link
              </button>
              {isCoachOrAdmin && (
                <button
                  onClick={() => setShowNewPostModal(true)}
                  className="px-4 py-2 rounded-xl font-semibold text-sm flex items-center gap-2"
                  style={{ background: teamColor, color: '#000' }}
                >
                  <Edit className="w-4 h-4" /> New Post
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Upcoming Events Banner - Always show */}
        <div className={`${tc.cardBg} rounded-2xl p-5 border ${tc.border}`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`font-bold ${tc.text} flex items-center gap-2`}>
              📆 Upcoming Events
            </h2>
            {upcomingEvents.length > 0 && (
              <span className={`text-xs ${tc.textMuted}`}>{upcomingEvents.length} upcoming</span>
            )}
          </div>
          
          {upcomingEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {upcomingEvents.slice(0, 3).map(event => (
                <EventMiniCard 
                  key={event.id} 
                  event={event} 
                  teamColor={teamColor}
                  onClick={() => setSelectedEvent(event)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <Calendar className="w-10 h-10" />
              <p className={`${tc.textSecondary} mt-2`}>No upcoming events scheduled</p>
              <p className={`${tc.textMuted} text-sm mt-1`}>Events will appear here when scheduled for this team</p>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className={`flex gap-1 p-1 rounded-xl ${tc.cardBg} border ${tc.border} w-fit`}>
          {[
            { id: 'feed', label: 'Feed', count: posts.length },
            { id: 'roster', label: 'Roster', count: roster.length },
            { id: 'coaches', label: 'Coach Coaches', count: coaches.length },
            { id: 'documents', label: '📁 Documents', count: documents.length },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === tab.id 
                  ? 'text-black' 
                  : `${tc.textSecondary} hover:${tc.text}`
              }`}
              style={activeTab === tab.id ? { background: teamColor } : {}}
            >
              {tab.label} {tab.count > 0 && `(${tab.count})`}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="pb-8">
          {/* Feed Tab */}
          {activeTab === 'feed' && (
            <div className="space-y-4">
              {posts.length === 0 ? (
                <div className={`${tc.cardBg} rounded-2xl p-12 text-center border ${tc.border}`}>
                  <Megaphone className="w-12 h-12 mx-auto text-slate-400" />
                  <h3 className={`text-lg font-medium ${tc.text} mt-4`}>No posts yet</h3>
                  <p className={`${tc.textSecondary} mt-2`}>
                    {isCoachOrAdmin ? "Create the first post to share with the team!" : "Check back soon for team updates!"}
                  </p>
                  {isCoachOrAdmin && (
                    <button
                      onClick={() => setShowNewPostModal(true)}
                      className="mt-4 px-6 py-2 rounded-xl font-semibold"
                      style={{ background: teamColor, color: '#000' }}
                    >
                      Create First Post
                    </button>
                  )}
                </div>
              ) : (
                posts.map(post => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    teamColor={teamColor}
                    onReact={() => toggleReaction(post.id)}
                    onComment={(content) => addComment(post.id, content)}
                    onDelete={isCoachOrAdmin ? () => deletePost(post.id) : null}
                    onExpand={() => setExpandedPost(post)}
                    currentUserId={profile?.id}
                  />
                ))
              )}
            </div>
          )}

          {/* Roster Tab */}
          {activeTab === 'roster' && (
            <div className={`${tc.cardBg} rounded-2xl p-6 border ${tc.border}`}>
              {roster.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12" />
                  <h3 className={`text-lg font-medium ${tc.text} mt-4`}>No players on roster</h3>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {roster.map(player => (
                    <div
                      key={player.id}
                      onClick={() => setSelectedPlayer(player)}
                      className="cursor-pointer group"
                    >
                      <div 
                        className="rounded-xl p-4 text-center transition group-hover:scale-105"
                        style={{ background: `${teamColor}15`, border: `2px solid ${teamColor}30` }}
                      >
                        {player.photo_url ? (
                          <img src={player.photo_url} alt="" className="w-16 h-16 rounded-full mx-auto object-cover border-2" style={{ borderColor: teamColor }} />
                        ) : (
                          <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center text-2xl" style={{ background: `${teamColor}30` }}>
                            {player.jersey_number || '-'}
                          </div>
                        )}
                        <p className={`font-medium ${tc.text} mt-2 text-sm`}>{player.first_name} {player.last_name?.[0]}.</p>
                        <div className="flex items-center justify-center gap-2 mt-1">
                          {player.jersey_number && (
                            <span className="text-xs font-bold px-2 py-0.5 rounded" style={{ background: teamColor, color: '#000' }}>
                              #{player.jersey_number}
                            </span>
                          )}
                          {player.position && (
                            <span className={`text-xs ${tc.textMuted}`}>{player.position}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Coaches Tab */}
          {activeTab === 'coaches' && (
            <div className={`${tc.cardBg} rounded-2xl p-6 border ${tc.border}`}>
              {coaches.length === 0 ? (
                <div className="text-center py-12">
                  <span className="text-5xl">Coach</span>
                  <h3 className={`text-lg font-medium ${tc.text} mt-4`}>No coaches assigned</h3>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {coaches.map(coach => (
                    <div
                      key={coach.id}
                      onClick={() => setSelectedCoach(coach)}
                      className="cursor-pointer"
                    >
                      <div 
                        className={`rounded-xl p-4 flex items-center gap-4 transition hover:scale-[1.02]`}
                        style={{ background: isDark ? '#0a0a0a' : '#f3f4f6' }}
                      >
                        {coach.photo_url ? (
                          <img src={coach.photo_url} alt="" className="w-16 h-16 rounded-full object-cover border-2 border-blue-500" />
                        ) : (
                          <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center">
                            <UserCog className="w-8 h-8 text-blue-400" />
                          </div>
                        )}
                        <div className="flex-1">
                          <p className={`font-semibold ${tc.text}`}>{coach.first_name} {coach.last_name}</p>
                          <p className="text-blue-400 text-sm">{coach.assignment_role === 'head' ? 'Head Coach' : coach.assignment_role || 'Coach'}</p>
                          <div className="flex gap-3 mt-2">
                            {coach.email && (
                              <a href={`mailto:${coach.email}`} onClick={e => e.stopPropagation()} className="text-xs text-[var(--accent-primary)] hover:underline">Email</a>
                            )}
                            {coach.phone && (
                              <a href={`tel:${coach.phone}`} onClick={e => e.stopPropagation()} className="text-xs text-[var(--accent-primary)] hover:underline">Call</a>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Documents Tab */}
          {activeTab === 'documents' && (
            <div className={`${tc.cardBg} rounded-2xl p-6 border ${tc.border}`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-semibold ${tc.text}`}>Team Documents</h3>
                {isCoachOrAdmin && (
                  <button
                    onClick={() => setShowUploadDocModal(true)}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium"
                    style={{ background: teamColor, color: '#000' }}
                  >
                    📤 Upload
                  </button>
                )}
              </div>
              
              {documents.length === 0 ? (
                <div className="text-center py-12">
                  <span className="text-5xl">📁</span>
                  <h3 className={`text-lg font-medium ${tc.text} mt-4`}>No documents yet</h3>
                  <p className={`${tc.textSecondary} mt-2`}>Team documents will appear here</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {documents.map(doc => (
                    <a
                      key={doc.id}
                      href={doc.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center justify-between p-3 rounded-xl transition ${tc.hoverBg}`}
                      style={{ background: isDark ? '#0a0a0a' : '#f3f4f6' }}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">
                          {doc.file_type === 'pdf' ? '📕' : doc.file_type === 'image' ? '🖼️' : '📄'}
                        </span>
                        <div>
                          <p className={`font-medium ${tc.text}`}>{doc.name}</p>
                          {doc.description && <p className={`text-xs ${tc.textMuted}`}>{doc.description}</p>}
                        </div>
                      </div>
                      <div className={`text-xs ${tc.textMuted}`}>
                        {doc.category && <span className="mr-2 px-2 py-0.5 rounded bg-gray-500/20">{doc.category}</span>}
                        {new Date(doc.created_at).toLocaleDateString()}
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showNewPostModal && (
        <NewPostModal
          teamColor={teamColor}
          onClose={() => setShowNewPostModal(false)}
          onSubmit={createPost}
        />
      )}

      {showUploadDocModal && (
        <UploadDocumentModal
          onClose={() => setShowUploadDocModal(false)}
          onSubmit={uploadDocument}
        />
      )}

      {selectedPlayer && (
        <PlayerCardExpanded
          player={selectedPlayer}
          visible={!!selectedPlayer}
          onClose={() => setSelectedPlayer(null)}
          context="roster"
        />
      )}

      {selectedCoach && (
        <CoachDetailModal
          coach={selectedCoach}
          onClose={() => setSelectedCoach(null)}
        />
      )}

      {selectedEvent && (
        <TeamWallEventModal
          event={selectedEvent}
          teamColor={teamColor}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  )
}

// Simple Event Detail Modal for Team Wall (read-only, parent-friendly)
function TeamWallEventModal({ event, teamColor, onClose }) {
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const eventDate = new Date(event.event_date)
  const formattedDate = eventDate.toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  })
  
  const typeLabels = {
    practice: { label: 'Practice', icon: 'volleyball', color: '#22C55E' },
    game: { label: 'Game', icon: 'trophy', color: '#F59E0B' },
    tournament: { label: 'Tournament', icon: 'target', color: '#8B5CF6' },
    meeting: { label: 'Team Meeting', icon: 'clipboard', color: '#3B82F6' },
    other: { label: 'Event', icon: '📌', color: '#6B7280' }
  }
  
  const eventType = typeLabels[event.event_type] || typeLabels.other

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className={`${tc.cardBg} border ${tc.border} rounded-2xl w-full max-w-md overflow-hidden`}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div 
          className="p-5 relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${teamColor}30 0%, ${teamColor}10 100%)` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl"
                style={{ background: `${eventType.color}20` }}
              >
                {eventType.icon}
              </div>
              <div>
                <span 
                  className="px-2 py-0.5 rounded-full text-xs font-semibold"
                  style={{ background: eventType.color, color: '#fff' }}
                >
                  {eventType.label}
                </span>
                <h2 className={`text-xl font-bold ${tc.text} mt-1`}>
                  {event.title || eventType.label}
                </h2>
              </div>
            </div>
            <button onClick={onClose} className={`${tc.textSecondary} hover:${tc.text} text-2xl`}>×</button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Date & Time */}
          <div className="flex items-start gap-3">
            <Calendar className="w-6 h-6" />
            <div>
              <p className={`font-medium ${tc.text}`}>{formattedDate}</p>
              {event.event_time && (
                <p className={tc.textSecondary}>
                  {formatTime12(event.event_time)}
                  {event.end_time && ` - ${formatTime12(event.end_time)}`}
                </p>
              )}
            </div>
          </div>

          {/* Location */}
          {(event.venue_name || event.venue_address) && (
            <div className="flex items-start gap-3">
              <span className="text-xl">📍</span>
              <div>
                {event.venue_name && <p className={`font-medium ${tc.text}`}>{event.venue_name}</p>}
                {event.venue_address && (
                  <a 
                    href={`https://maps.google.com/?q=${encodeURIComponent(event.venue_address)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[var(--accent-primary)] hover:underline text-sm"
                  >
                    {event.venue_address} →
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Opponent (for games) */}
          {event.event_type === 'game' && event.opponent_name && (
            <div className="flex items-start gap-3">
              <span className="text-xl">⚔️</span>
              <div>
                <p className={tc.textSecondary}>Opponent</p>
                <p className={`font-medium ${tc.text}`}>{event.opponent_name}</p>
              </div>
            </div>
          )}

          {/* Home/Away */}
          {event.location_type && (
            <div className="flex items-start gap-3">
              <span className="text-xl">{event.location_type === 'home' ? '🏠' : '🚗'}</span>
              <div>
                <p className={`font-medium ${tc.text}`}>
                  {event.location_type === 'home' ? 'Home Game' : 'Away Game'}
                </p>
              </div>
            </div>
          )}

          {/* Description */}
          {event.description && (
            <div className="flex items-start gap-3">
              <span className="text-xl">📝</span>
              <div>
                <p className={tc.textSecondary}>Notes</p>
                <p className={`${tc.text} text-sm whitespace-pre-wrap`}>{event.description}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className={`p-4 border-t ${tc.border} flex justify-between items-center`}>
          <div className={`text-xs ${tc.textMuted}`}>
            {event.event_type === 'game' && '🏆 Game Day!'}
            {event.event_type === 'practice' && '💪 Let\'s work hard!'}
            {event.event_type === 'tournament' && '🎯 Tournament time!'}
          </div>
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl font-semibold"
            style={{ background: teamColor, color: '#000' }}
          >
            Got it!
          </button>
        </div>
      </div>
    </div>
  )
}

// Mini Event Card for Team Wall
function EventMiniCard({ event, teamColor, onClick }) {
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  
  const eventDate = new Date(event.event_date)
  const dayName = eventDate.toLocaleDateString('en-US', { weekday: 'short' })
  const monthDay = eventDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  
  const typeIcons = {
    practice: 'practice',
    game: '🏆',
    tournament: '🎯',
    meeting: '📋',
    other: '📌'
  }

  return (
    <div 
      className="rounded-xl p-4 transition hover:scale-[1.02] cursor-pointer"
      style={{ background: isDark ? '#0a0a0a' : '#f3f4f6' }}
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <div 
          className="w-12 h-12 rounded-lg flex flex-col items-center justify-center text-xs font-bold"
          style={{ background: `${teamColor}20`, color: teamColor }}
        >
          <span>{dayName}</span>
          <span className="text-sm">{eventDate.getDate()}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`font-medium ${tc.text} text-sm truncate`}>
            {typeIcons[event.event_type] || '📌'} {event.title || event.event_type}
          </p>
          <p className={`text-xs ${tc.textMuted} mt-0.5`}>
            {event.event_time && formatTime12(event.event_time)}
            {event.venue_name && ` • ${event.venue_name}`}
          </p>
          {event.event_type === 'game' && event.opponent_name && (
            <p className="text-xs text-orange-400 mt-1">vs {event.opponent_name}</p>
          )}
        </div>
      </div>
    </div>
  )
}

// Post Card Component
function PostCard({ post, teamColor, onReact, onComment, onDelete, onExpand, currentUserId }) {
  const tc = useThemeClasses()
  const { isDark } = useTheme()
  const [showCommentInput, setShowCommentInput] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [userReacted, setUserReacted] = useState(false)

  const PostTypeIcon = ({ type }) => {
    switch(type) {
      case 'announcement': return <Megaphone className="w-4 h-4 inline" />
      case 'photo': return <Camera className="w-4 h-4 inline" />
      case 'milestone': return <Trophy className="w-4 h-4 inline" />
      case 'game_recap': return <BarChart3 className="w-4 h-4 inline" />
      case 'shoutout': return <Star className="w-4 h-4 inline" />
      default: return <Megaphone className="w-4 h-4 inline" />
    }
  }

  const timeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000)
    if (seconds < 60) return 'Just now'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    const days = Math.floor(hours / 24)
    if (days < 7) return `${days}d ago`
    return new Date(date).toLocaleDateString()
  }

  const handleComment = () => {
    if (commentText.trim()) {
      onComment(commentText)
      setCommentText('')
      setShowCommentInput(false)
    }
  }

  return (
    <div className={`${tc.cardBg} rounded-2xl border ${tc.border} overflow-hidden`}>
      {/* Post Header */}
      <div className="p-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          {post.profiles?.avatar_url ? (
            <img src={post.profiles.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover" />
          ) : (
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg" style={{ background: `${teamColor}30` }}>
              {post.profiles?.full_name?.[0] || '?'}
            </div>
          )}
          <div>
            <p className={`font-medium ${tc.text}`}>{post.profiles?.full_name || 'Team Admin'}</p>
            <p className={`text-xs ${tc.textMuted} flex items-center gap-1`}>
              <PostTypeIcon type={post.post_type} /> {timeAgo(post.created_at)}
              {post.is_pinned && <span className="ml-2 text-[var(--accent-primary)] flex items-center gap-1"><Flag className="w-3 h-3" />Pinned</span>}
            </p>
          </div>
        </div>
        {onDelete && post.author_id === currentUserId && (
          <button onClick={onDelete} className="text-slate-500 hover:text-red-400 text-sm"><Trash2 className="w-4 h-4" /></button>
        )}
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        {post.title && <h3 className={`font-semibold ${tc.text} text-lg mb-2`}>{post.title}</h3>}
        {post.content && <p className={`${tc.textSecondary} whitespace-pre-wrap`}>{post.content}</p>}
      </div>

      {/* Media Grid */}
      {post.media_urls && post.media_urls.length > 0 && (
        <div className={`px-4 pb-3 grid gap-2 ${post.media_urls.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
          {post.media_urls.slice(0, 4).map((url, idx) => (
            <div key={idx} className="relative">
              <img 
                src={url} 
                alt="" 
                className="w-full h-48 object-cover rounded-lg cursor-pointer hover:opacity-90"
                onClick={onExpand}
              />
              {idx === 3 && post.media_urls.length > 4 && (
                <div className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                  +{post.media_urls.length - 4}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Engagement Bar */}
      <div className={`px-4 py-3 border-t ${tc.border} flex items-center justify-between`}>
        <div className="flex items-center gap-4">
          <button 
            onClick={onReact}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${
              userReacted ? 'bg-red-500/20 text-red-400' : `${tc.hoverBg} ${tc.textSecondary}`
            }`}
          >
            ❤️ <span className="text-sm">{post.reaction_count || 0}</span>
          </button>
          <button 
            onClick={() => setShowCommentInput(!showCommentInput)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition ${tc.hoverBg} ${tc.textSecondary}`}
          >
            💬 <span className="text-sm">{post.comment_count || 0}</span>
          </button>
        </div>
        <button className={`${tc.textMuted} text-sm hover:${tc.text}`}>
          📤 Share
        </button>
      </div>

      {/* Comment Input */}
      {showCommentInput && (
        <div className={`px-4 pb-4 border-t ${tc.border}`}>
          <div className="flex gap-2 mt-3">
            <input
              type="text"
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              placeholder="Write a comment..."
              className={`flex-1 px-4 py-2 rounded-xl ${tc.inputBg} border ${tc.border} ${tc.text} text-sm`}
              onKeyDown={e => e.key === 'Enter' && handleComment()}
            />
            <button
              onClick={handleComment}
              disabled={!commentText.trim()}
              className="px-4 py-2 rounded-xl font-medium text-sm disabled:opacity-50"
              style={{ background: teamColor, color: '#000' }}
            >
              Post
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// New Post Modal
function NewPostModal({ teamColor, onClose, onSubmit }) {
  const tc = useThemeClasses()
  const [form, setForm] = useState({
    post_type: 'announcement',
    title: '',
    content: '',
    media_urls: [],
    is_pinned: false
  })

  const postTypes = [
    { value: 'announcement', label: 'Announcement' },
    { value: 'photo', label: '📸 Photos' },
    { value: 'milestone', label: '🏆 Milestone' },
    { value: 'game_recap', label: '📊 Game Recap' },
    { value: 'shoutout', label: 'Shoutout' },
  ]

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className={`${tc.cardBg} border ${tc.border} rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto`}
        onClick={e => e.stopPropagation()}
      >
        <div className={`p-5 border-b ${tc.border} flex items-center justify-between`}>
          <h2 className={`text-xl font-bold ${tc.text}`}>Create Post</h2>
          <button onClick={onClose} className={`${tc.textSecondary} hover:${tc.text} text-2xl`}>×</button>
        </div>

        <div className="p-5 space-y-4">
          {/* Post Type */}
          <div className="flex flex-wrap gap-2">
            {postTypes.map(type => (
              <button
                key={type.value}
                onClick={() => setForm({ ...form, post_type: type.value })}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                  form.post_type === type.value 
                    ? 'text-black' 
                    : `${tc.cardBgAlt} ${tc.textSecondary}`
                }`}
                style={form.post_type === type.value ? { background: teamColor } : {}}
              >
                {type.label}
              </button>
            ))}
          </div>

          {/* Title */}
          <input
            type="text"
            value={form.title}
            onChange={e => setForm({ ...form, title: e.target.value })}
            placeholder="Post title (optional)"
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text}`}
          />

          {/* Content */}
          <textarea
            value={form.content}
            onChange={e => setForm({ ...form, content: e.target.value })}
            placeholder="What's happening with the team?"
            rows={4}
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text} resize-none`}
          />

          {/* Pin Option */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={form.is_pinned}
              onChange={e => setForm({ ...form, is_pinned: e.target.checked })}
              className="w-4 h-4 rounded"
            />
            <span className={tc.textSecondary}>📌 Pin to top of feed</span>
          </label>
        </div>

        <div className={`p-5 border-t ${tc.border} flex justify-end gap-3`}>
          <button onClick={onClose} className={`px-6 py-2 rounded-xl ${tc.cardBgAlt} ${tc.text}`}>
            Cancel
          </button>
          <button
            onClick={() => onSubmit(form)}
            disabled={!form.content.trim()}
            className="px-6 py-2 rounded-xl font-semibold disabled:opacity-50"
            style={{ background: teamColor, color: '#000' }}
          >
            Post
          </button>
        </div>
      </div>
    </div>
  )
}

// Upload Document Modal
function UploadDocumentModal({ onClose, onSubmit }) {
  const tc = useThemeClasses()
  const [form, setForm] = useState({
    name: '',
    description: '',
    file_url: '',
    file_type: 'pdf',
    category: 'general'
  })

  const categories = ['general', 'schedule', 'rules', 'tournament', 'training']

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div 
        className={`${tc.cardBg} border ${tc.border} rounded-2xl w-full max-w-md`}
        onClick={e => e.stopPropagation()}
      >
        <div className={`p-5 border-b ${tc.border} flex items-center justify-between`}>
          <h2 className={`text-xl font-bold ${tc.text}`}>Upload Document</h2>
          <button onClick={onClose} className={`${tc.textSecondary} hover:${tc.text} text-2xl`}>×</button>
        </div>

        <div className="p-5 space-y-4">
          <input
            type="text"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            placeholder="Document name *"
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text}`}
          />

          <input
            type="text"
            value={form.description}
            onChange={e => setForm({ ...form, description: e.target.value })}
            placeholder="Description (optional)"
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text}`}
          />

          <input
            type="url"
            value={form.file_url}
            onChange={e => setForm({ ...form, file_url: e.target.value })}
            placeholder="File URL (Google Drive, Dropbox, etc.) *"
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text}`}
          />

          <select
            value={form.category}
            onChange={e => setForm({ ...form, category: e.target.value })}
            className={`w-full px-4 py-3 rounded-xl ${tc.cardBgAlt} border ${tc.border} ${tc.text}`}
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
            ))}
          </select>
        </div>

        <div className={`p-5 border-t ${tc.border} flex justify-end gap-3`}>
          <button onClick={onClose} className={`px-6 py-2 rounded-xl ${tc.cardBgAlt} ${tc.text}`}>
            Cancel
          </button>
          <button
            onClick={() => onSubmit(form)}
            disabled={!form.name.trim() || !form.file_url.trim()}
            className="px-6 py-2 rounded-xl font-semibold bg-[var(--accent-primary)] text-white disabled:opacity-50"
          >
            Upload
          </button>
        </div>
      </div>
    </div>
  )
}


export { TeamWallPage }
