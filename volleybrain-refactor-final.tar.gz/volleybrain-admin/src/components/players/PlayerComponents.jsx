import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { 
  User, Users, DollarSign, ClipboardList, MessageCircle, Calendar, 
  Check, X, Edit, Trash2, Plus, Eye, Download, Upload, Settings,
  BarChart3, Target, Bell, Lock, Unlock, Globe, CreditCard,
  Mail, Phone, MapPin, Home, AlertTriangle, Shirt
} from '../../constants/icons'

// ============================================
// CONSTANTS
// ============================================
export const positionColors = {
  'OH': '#FF6B6B', 'S': '#4ECDC4', 'MB': '#45B7D1', 'OPP': '#96CEB4',
  'L': '#FFEAA7', 'DS': '#DDA0DD', 'RS': '#FF9F43'
}

export const positionNames = {
  'OH': 'Outside Hitter', 'S': 'Setter', 'MB': 'Middle Blocker',
  'OPP': 'Opposite', 'L': 'Libero', 'DS': 'Defensive Specialist', 'RS': 'Right Side'
}

// Icon mapping for action buttons and contact rows
export const getIconComponent = (iconName, size = "w-4 h-4") => {
  const iconMap = {
    user: User,
    users: Users,
    clipboard: ClipboardList,
    dollar: DollarSign,
    shirt: Shirt,
    mail: Mail,
    phone: Phone,
    smartphone: Phone,
    map: MapPin,
    home: Home,
    calendar: Calendar,
    message: MessageCircle,
    'alert-triangle': AlertTriangle,
    check: Check,
    x: X,
    edit: Edit,
    trash: Trash2,
    plus: Plus,
    eye: Eye,
    download: Download,
    upload: Upload,
    settings: Settings,
    'bar-chart': BarChart3,
    target: Target,
    bell: Bell,
    lock: Lock,
    unlock: Unlock,
    globe: Globe,
    'credit-card': CreditCard,
  }
  const IconComp = iconMap[iconName]
  return IconComp ? <IconComp className={size} /> : <span>{iconName}</span>
}

// ============================================
// HELPER COMPONENTS
// ============================================
export function InfoBox({ label, value }) {
  return (
    <div className="bg-slate-900 rounded-lg p-3">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-white font-medium">{value || '—'}</div>
    </div>
  )
}

export function ActionButton({ label, icon, onClick }) {
  return (
    <button onClick={onClick} className="px-3 py-2 bg-slate-900 rounded-lg text-sm text-gray-300 hover:bg-slate-700 hover:text-white transition flex items-center gap-2">
      {getIconComponent(icon, "w-4 h-4")} {label}
    </button>
  )
}

export function PlayerWaiverBadge({ label, signed }) {
  return (
    <div className={`rounded-lg p-2 text-center ${signed ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
      <div className={`flex items-center justify-center ${signed ? 'text-emerald-400' : 'text-red-400'}`}>
        {signed ? <Check className="w-5 h-5" /> : <X className="w-5 h-5" />}
      </div>
      <div className="text-xs text-slate-400">{label}</div>
    </div>
  )
}

export function ContactRow({ icon, label, value, link }) {
  const content = (
    <div className="flex items-center justify-between py-1">
      <span className="text-slate-500 text-sm flex items-center gap-2">{getIconComponent(icon, "w-4 h-4")} {label}</span>
      <span className={`text-white ${link ? 'hover:text-[var(--accent-primary)]' : ''}`}>{value || '—'}</span>
    </div>
  )
  return link && value ? <a href={link}>{content}</a> : content
}

export function DocumentRow({ label, url }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-slate-400">{label}</span>
      {url ? (
        <a href={url} target="_blank" rel="noopener noreferrer" className="text-[var(--accent-primary)] hover:underline text-sm">View →</a>
      ) : (
        <span className="text-slate-600 text-sm">Not uploaded</span>
      )}
    </div>
  )
}

// ============================================
// PLAYER CARD (Compact view)
// ============================================
export function PlayerCard({ player, context = 'roster', teamColor, onClick, showPhoto = true, size = 'medium' }) {
  const posColor = player.position ? positionColors[player.position] || '#EAB308' : '#EAB308'
  const cardColor = teamColor || posColor

  // Context-specific data
  const getContextInfo = () => {
    switch (context) {
      case 'registration':
        return [
          { label: 'Status', value: player.registration_status || player.status, color: getStatusColor(player.registration_status || player.status) },
          { label: 'Waiver', value: player.waiver_signed ? '✓ Signed' : '⚠️ Pending', color: player.waiver_signed ? '#4ECDC4' : '#FF6B6B' },
          { label: 'Jersey', value: player.jersey_number ? `#${player.jersey_number}` : 'Not Set' }
        ]
      case 'payment':
        return [
          { label: 'Balance', value: player.balance ? `$${player.balance}` : '$0', color: player.balance > 0 ? '#FF6B6B' : '#4ECDC4' },
          { label: 'Last Paid', value: player.last_paid_date || 'Never' },
          { label: 'Plan', value: player.payment_plan || 'N/A' }
        ]
      case 'attendance':
        return [
          { label: 'RSVP', value: player.rsvp_status || 'Pending', color: player.rsvp_status === 'yes' ? '#4ECDC4' : player.rsvp_status === 'no' ? '#FF6B6B' : '#FFB347' },
          { label: 'Rate', value: player.attendance_rate ? `${player.attendance_rate}%` : 'N/A' },
          { label: 'Last', value: player.last_attendance || 'N/A' }
        ]
      case 'jersey':
        return [
          { label: 'Number', value: player.jersey_number ? `#${player.jersey_number}` : 'None', color: cardColor },
          { label: 'Size', value: player.uniform_size_jersey || 'N/A' },
          { label: 'Prefs', value: [player.jersey_pref_1, player.jersey_pref_2, player.jersey_pref_3].filter(Boolean).join(', ') || 'None' }
        ]
      default: // roster
        return [
          { label: 'POS', value: player.position || '—', color: posColor },
          { label: 'GRD', value: player.grade || '—' },
          { label: 'JRS', value: player.jersey_number ? `#${player.jersey_number}` : '—', color: cardColor }
        ]
    }
  }

  const getStatusColor = (status) => {
    const colors = {
      'new': '#FFB347', 'pending': '#FFB347', 'submitted': '#FFB347',
      'approved': '#4ECDC4', 'rostered': '#4ECDC4', 'active': '#4ECDC4', 'assigned': '#4ECDC4',
      'denied': '#FF6B6B', 'withdrawn': '#FF6B6B', 'inactive': '#FF6B6B'
    }
    return colors[status?.toLowerCase()] || '#6B7280'
  }

  const contextInfo = getContextInfo()
  const sizeClasses = {
    small: 'w-32 h-40',
    medium: 'w-40 h-48',
    large: 'w-48 h-56'
  }

  return (
    <div
      onClick={onClick}
      className={`relative rounded-xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl ${sizeClasses[size]}`}
      style={{ background: `linear-gradient(135deg, ${cardColor}30 0%, #0a0a0a 100%)` }}
    >
      {/* Position badge */}
      {player.position && (
        <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-xs font-bold" style={{ backgroundColor: posColor, color: '#000' }}>
          {player.position}
        </div>
      )}

      {/* Jersey number */}
      {player.jersey_number && (
        <div className="absolute top-2 right-2 text-2xl font-black" style={{ color: cardColor, textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>
          {player.jersey_number}
        </div>
      )}

      {/* Photo/Silhouette */}
      <div className="flex justify-center pt-8 pb-2">
        {showPhoto && player.photo_url ? (
          <img src={player.photo_url} alt="" className="w-16 h-16 rounded-full border-2 object-cover" style={{ borderColor: posColor + '60' }} />
        ) : (
          <div className="w-16 h-16 rounded-full bg-[#1a1a2e] border-2 flex items-center justify-center" style={{ borderColor: cardColor + '40' }}>
            <span className="flex items-center justify-center"><User className="w-6 h-6 text-slate-600" /></span>
          </div>
        )}
      </div>

      {/* Name bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/80 px-3 py-2">
        <div className="text-white font-bold text-sm truncate">{player.first_name} {player.last_name?.charAt(0)}.</div>
        
        {/* Context info row */}
        <div className="flex justify-between mt-1">
          {contextInfo.map((info, i) => (
            <div key={i} className="text-center">
              <div className="text-[10px] text-slate-500">{info.label}</div>
              <div className="text-xs font-semibold" style={{ color: info.color || '#fff' }}>{info.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom accent */}
      <div className="absolute bottom-0 left-0 right-0 h-1" style={{ backgroundColor: posColor }} />
    </div>
  )
}

// ============================================
// PLAYER CARD EXPANDED (Full detail modal)
// ============================================
export function PlayerCardExpanded({ player, visible, onClose, onNavigate, context = 'roster' }) {
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(false)
  const [playerData, setPlayerData] = useState(null)
  const [registrations, setRegistrations] = useState([])
  const [payments, setPayments] = useState([])
  const [teamAssignments, setTeamAssignments] = useState([])

  useEffect(() => {
    if (visible && player?.id) {
      loadPlayerData()
    }
  }, [visible, player?.id])

  async function loadPlayerData() {
    setLoading(true)
    try {
      // Load full player data
      const { data: fullPlayer } = await supabase
        .from('players')
        .select('*')
        .eq('id', player.id)
        .single()
      setPlayerData(fullPlayer)

      // Load registrations
      const { data: regs } = await supabase
        .from('registrations')
        .select('*, seasons(name)')
        .eq('player_id', player.id)
        .order('created_at', { ascending: false })
      setRegistrations(regs || [])

      // Load payments
      const { data: pays } = await supabase
        .from('payments')
        .select('*')
        .eq('player_id', player.id)
        .order('created_at', { ascending: false })
      setPayments(pays || [])

      // Load team assignments
      const { data: teams } = await supabase
        .from('team_players')
        .select('*, teams(id, name, color, seasons(name))')
        .eq('player_id', player.id)
      setTeamAssignments(teams || [])

    } catch (err) {
      console.error('Error loading player data:', err)
    }
    setLoading(false)
  }

  if (!visible || !player) return null

  const p = playerData || player
  const posColor = p.position ? positionColors[p.position] || '#EAB308' : '#EAB308'

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'user' },
    { id: 'registration', label: 'Registration', icon: 'clipboard' },
    { id: 'payments', label: 'Payments', icon: 'dollar' },
    { id: 'contact', label: 'Contact', icon: '📞' },
    { id: 'medical', label: 'Medical', icon: '🏥' },
  ]

  // Calculate payment stats
  const totalPaid = payments.filter(p => p.paid).reduce((sum, p) => sum + (p.amount || 0), 0)
  const totalOwed = payments.filter(p => !p.paid).reduce((sum, p) => sum + (p.amount || 0), 0)

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="relative p-6 text-center" style={{ background: `linear-gradient(180deg, ${posColor}30 0%, #141414 100%)` }}>
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white text-2xl">×</button>
          
          {/* Photo */}
          <div className="flex justify-center mb-4">
            {p.photo_url ? (
              <img src={p.photo_url} alt="" className="w-24 h-24 rounded-full border-4 object-cover" style={{ borderColor: posColor + '60' }} />
            ) : (
              <div className="w-24 h-24 rounded-full bg-[#1a1a2e] border-4 flex items-center justify-center" style={{ borderColor: posColor + '40' }}>
                <span className="flex items-center justify-center"><User className="w-10 h-10 text-slate-600" /></span>
              </div>
            )}
          </div>

          {/* Name & Jersey */}
          {p.jersey_number && <div className="text-slate-400 text-sm">#{p.jersey_number}</div>}
          <h2 className="text-2xl font-bold text-white">{p.first_name} {p.last_name}</h2>
          
          {/* Position & Team */}
          <div className="flex items-center justify-center gap-3 mt-2">
            {p.position && (
              <span className="px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: posColor, color: '#000' }}>
                {positionNames[p.position] || p.position}
              </span>
            )}
            {teamAssignments[0]?.teams?.name && (
              <span className="text-slate-400">{teamAssignments[0].teams.name}</span>
            )}
          </div>

          {/* Quick stats */}
          <div className="flex justify-center gap-6 mt-4">
            <div className="text-center">
              <div className="text-lg font-bold text-white">{p.grade || '—'}</div>
              <div className="text-xs text-slate-500">Grade</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={{ color: posColor }}>{p.position || '—'}</div>
              <div className="text-xs text-slate-500">Position</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-white">{teamAssignments.length}</div>
              <div className="text-xs text-slate-500">Teams</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold" style={{ color: totalOwed > 0 ? '#FF6B6B' : '#4ECDC4' }}>
                ${totalOwed > 0 ? totalOwed : totalPaid}
              </div>
              <div className="text-xs text-slate-500">{totalOwed > 0 ? 'Owed' : 'Paid'}</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-700">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 text-sm font-medium transition ${
                activeTab === tab.id ? 'text-[var(--accent-primary)] border-b-2 border-[var(--accent-primary)]' : 'text-slate-500 hover:text-gray-300'
              }`}
            >
              <span className="mr-1">{tab.icon}</span> {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="text-center py-8 text-slate-400">Loading...</div>
          ) : (
            <>
              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <InfoBox label="School" value={p.school} />
                    <InfoBox label="Experience" value={p.experience_level || p.experience} />
                    <InfoBox label="Jersey Size" value={p.uniform_size_jersey} />
                    <InfoBox label="Shorts Size" value={p.uniform_size_shorts} />
                    <InfoBox label="Jersey Prefs" value={[p.jersey_pref_1, p.jersey_pref_2, p.jersey_pref_3].filter(Boolean).join(', ')} />
                    <InfoBox label="Status" value={p.status} />
                  </div>

                  {/* Quick Actions */}
                  <div className="mt-6">
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Quick Actions</h4>
                    <div className="flex flex-wrap gap-2">
                      <ActionButton label="View Registrations" icon="clipboard" onClick={() => setActiveTab('registration')} />
                      <ActionButton label="View Payments" icon="dollar" onClick={() => setActiveTab('payments')} />
                      {onNavigate && <ActionButton label="Go to Team" icon="users" onClick={() => { onClose(); onNavigate('teams'); }} />}
                      {onNavigate && <ActionButton label="Edit Jersey" icon="shirt" onClick={() => { onClose(); onNavigate('jerseys'); }} />}
                    </div>
                  </div>

                  {/* Team Assignments */}
                  {teamAssignments.length > 0 && (
                    <div className="mt-6">
                      <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Team Assignments</h4>
                      {teamAssignments.map(ta => (
                        <div key={ta.id} className="bg-slate-900 rounded-lg p-3 mb-2 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ta.teams?.color || '#EAB308' }} />
                            <span className="text-white">{ta.teams?.name}</span>
                          </div>
                          <span className="text-slate-500 text-sm">{ta.teams?.seasons?.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Registration Tab */}
              {activeTab === 'registration' && (
                <div className="space-y-4">
                  {/* Waiver Status */}
                  <div className="bg-slate-900 rounded-xl p-4">
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Waiver Status</h4>
                    <div className="grid grid-cols-3 gap-4">
                      <PlayerWaiverBadge label="Liability" signed={p.waiver_liability} />
                      <PlayerWaiverBadge label="Photo Release" signed={p.waiver_photo} />
                      <PlayerWaiverBadge label="Code of Conduct" signed={p.waiver_conduct} />
                    </div>
                    {p.waiver_signed_by && (
                      <div className="mt-3 text-sm text-slate-500">
                        Signed by: {p.waiver_signed_by} on {p.waiver_signed_date ? new Date(p.waiver_signed_date).toLocaleDateString() : 'N/A'}
                      </div>
                    )}
                  </div>

                  {/* Registration History */}
                  <div>
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Registration History</h4>
                    {registrations.length === 0 ? (
                      <p className="text-slate-500 text-sm">No registrations found</p>
                    ) : (
                      registrations.map(reg => (
                        <div key={reg.id} className="bg-slate-900 rounded-lg p-3 mb-2 flex items-center justify-between">
                          <div>
                            <span className="text-white">{reg.seasons?.name || 'Unknown Season'}</span>
                            <span className={`ml-2 px-2 py-0.5 rounded text-xs font-medium ${
                              reg.status === 'rostered' ? 'bg-emerald-500/20 text-emerald-400' :
                              reg.status === 'approved' ? 'bg-blue-500/20 text-blue-400' :
                              reg.status === 'pending' ? 'bg-[var(--accent-primary)]/20 text-[var(--accent-primary)]' :
                              'bg-gray-500/20 text-slate-400'
                            }`}>
                              {reg.status}
                            </span>
                          </div>
                          <span className="text-slate-500 text-sm">
                            {reg.submitted_at ? new Date(reg.submitted_at).toLocaleDateString() : ''}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Payments Tab */}
              {activeTab === 'payments' && (
                <div className="space-y-4">
                  {/* Summary */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold text-emerald-400">${totalPaid}</div>
                      <div className="text-xs text-emerald-400">Total Paid</div>
                    </div>
                    <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold text-red-400">${totalOwed}</div>
                      <div className="text-xs text-red-400">Outstanding</div>
                    </div>
                    <div className="bg-slate-900 rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold text-white">{payments.length}</div>
                      <div className="text-xs text-slate-400">Transactions</div>
                    </div>
                  </div>

                  {/* Payment History */}
                  <div>
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Payment History</h4>
                    {payments.length === 0 ? (
                      <p className="text-slate-500 text-sm">No payments found</p>
                    ) : (
                      payments.map(pay => (
                        <div key={pay.id} className="bg-slate-900 rounded-lg p-3 mb-2 flex items-center justify-between">
                          <div>
                            <span className="text-white">{pay.fee_name || pay.fee_type}</span>
                            <span className={`ml-2 px-2 py-0.5 rounded text-xs font-medium ${
                              pay.paid ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                            }`}>
                              {pay.paid ? 'Paid' : 'Unpaid'}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="text-white font-semibold">${pay.amount}</div>
                            <div className="text-slate-500 text-xs">{pay.paid_date || 'Pending'}</div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Contact Tab */}
              {activeTab === 'contact' && (
                <div className="space-y-4">
                  {/* Primary Parent */}
                  <div className="bg-slate-900 rounded-xl p-4">
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Primary Contact</h4>
                    <div className="space-y-2">
                      <ContactRow icon="user" label="Name" value={p.parent_name} />
                      <ContactRow icon="mail" label="Email" value={p.parent_email} link={`mailto:${p.parent_email}`} />
                      <ContactRow icon="phone" label="Phone" value={p.parent_phone} link={`tel:${p.parent_phone}`} />
                    </div>
                  </div>

                  {/* Secondary Parent */}
                  {p.parent_2_name && (
                    <div className="bg-slate-900 rounded-xl p-4">
                      <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Secondary Contact</h4>
                      <div className="space-y-2">
                        <ContactRow icon="user" label="Name" value={p.parent_2_name} />
                        <ContactRow icon="mail" label="Email" value={p.parent_2_email} link={`mailto:${p.parent_2_email}`} />
                        <ContactRow icon="phone" label="Phone" value={p.parent_2_phone} link={`tel:${p.parent_2_phone}`} />
                      </div>
                    </div>
                  )}

                  {/* Emergency Contact */}
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                    <h4 className="text-sm font-semibold text-red-400 uppercase mb-3">🚨 Emergency Contact</h4>
                    <div className="space-y-2">
                      <ContactRow icon="user" label="Name" value={p.emergency_contact_name || p.emergency_name} />
                      <ContactRow icon="phone" label="Phone" value={p.emergency_contact_phone || p.emergency_phone} link={`tel:${p.emergency_contact_phone || p.emergency_phone}`} />
                      <ContactRow icon="link" label="Relation" value={p.emergency_contact_relation || p.emergency_relation} />
                    </div>
                  </div>

                  {/* Address */}
                  {p.address && (
                    <div className="bg-slate-900 rounded-xl p-4">
                      <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Address</h4>
                      <p className="text-white">{p.address}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Medical Tab */}
              {activeTab === 'medical' && (
                <div className="space-y-4">
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                    <h4 className="text-sm font-semibold text-red-400 uppercase mb-3">⚠️ Medical Information</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="text-xs text-slate-500">Medical Conditions</label>
                        <p className="text-white">{p.medical_conditions || p.medical_notes || 'None reported'}</p>
                      </div>
                      <div>
                        <label className="text-xs text-slate-500">Allergies</label>
                        <p className="text-white">{p.allergies || 'None reported'}</p>
                      </div>
                      <div>
                        <label className="text-xs text-slate-500">Medications</label>
                        <p className="text-white">{p.medications || 'None reported'}</p>
                      </div>
                    </div>
                  </div>

                  {/* Documents */}
                  <div className="bg-slate-900 rounded-xl p-4">
                    <h4 className="text-sm font-semibold text-slate-400 uppercase mb-3">Documents</h4>
                    <div className="space-y-2">
                      <DocumentRow label="Birth Certificate" url={p.birth_certificate_url} />
                      <DocumentRow label="Medical Form" url={p.medical_form_url} />
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
